package com.example.ayappa.expenseapp;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.support.v4.app.Fragment;
import android.widget.Toast;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.Fragment;

import java.util.ArrayList;

class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

        ArrayList<list_details> detailsObjects;
        public Adapter(ArrayList<list_details> detailsObjects) {
            this.detailsObjects=detailsObjects;
        }

        public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.show,viewGroup,false);
            ViewHolder viewHolder=new ViewHolder(view);
            return viewHolder;
        }

        @Override

        public void onBindViewHolder(@NonNull Adapter.ViewHolder viewHolder, int i) {
            list_details details=detailsObjects.get(i);
            viewHolder.name.setText((CharSequence) details.name);
            viewHolder.amount.setText("$"+(CharSequence) details.amount);
            viewHolder.details1=details;
            viewHolder.list_detailsArrayList=detailsObjects;

        }

        @Override

        public int getItemCount() {

            return detailsObjects.size();

        }

        public static class ViewHolder extends RecyclerView.ViewHolder{

            TextView name;

            TextView amount;
            OnFragmentInteractionListener mListerner;
            public interface OnFragmentInteractionListener {
                // TODO: Update argument type and name
                void onFragmentInteraction(int position);
            }


            ArrayList<list_details> list_detailsArrayList=new ArrayList<list_details>();
            list_details details1;
            private int position;

            public ViewHolder(@NonNull final View itemView) {

                super(itemView);
                name=(TextView)itemView.findViewById(R.id.name);
                amount=(TextView)itemView.findViewById(R.id.amount);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String name=details1.name;
                        String cat=details1.cat;
                        String amount=details1.amount;
                        String date=details1.currentTime;
                        Log.d("adapter","date;="+date);
                        Bundle bundle=new Bundle();
                        bundle.putString("name", name );
                        bundle.putString("cat", cat );
                        bundle.putString("amount", amount );
                        bundle.putString("Date", date );
                        ShowFragment fragment=new ShowFragment();
                        fragment.setArguments(bundle);
                        Object context=itemView.getContext();
                        FragmentManager manager = ((AppCompatActivity)context).getSupportFragmentManager();
                        manager.beginTransaction().replace(R.id.layout,fragment,"third").addToBackStack(null).commit();
                    }
                });

                 itemView.setOnLongClickListener(new View.OnLongClickListener() {
                     @Override
                     public boolean onLongClick(View v) {
                         list_detailsArrayList.remove(position);
                         Toast.makeText(itemView.getContext(),"Iteam is Deleted",Toast.LENGTH_LONG).show();
                         Log.d("adapter12","seze_ON1;="+list_detailsArrayList.size());
                         Log.d("adapter12","position_ON1;="+position);
                         Log.d("adapter12","position_ON2;="+itemView.getContext());
                         return false;
                     }
                    // list_detailsArrayList.remove(position);
                     //Adapter adapter=new Adapter(list_detailsArrayList);
                 });
            }





        }

    }






