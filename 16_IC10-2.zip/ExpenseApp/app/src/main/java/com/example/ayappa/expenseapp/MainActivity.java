package com.example.ayappa.expenseapp;


//Assignment number =HW5
//Names:Amith Yarra
//      Ayappa Krishnappa
//      Shashank Chandreshaker


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    ArrayList<list_details> objects=new ArrayList<list_details>();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("expense");
    String name1;
    String amount1;
    String date1;
    Object image1;
    Bitmap imageBitmap;
    FirebaseStorage storage;
    StorageReference storageReference;
    private Uri filePath=null;
    String Storage_Path = "All_Image_Uploads/";
    String Database_Path = "All_Image_Uploads_Database";
    String imageurl;
    TextView txt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        SharedPreferences sharedPref = this.getPreferences(Context.MODE_PRIVATE);
       // int defaultValue = getResources().getInteger(R.integer.saved_high_score_default_key);
        String highScore = sharedPref.getString("key", null);
       // Toast.makeText(this, highScore, Toast.LENGTH_SHORT).show();
        Log.d("demoqq",highScore);
        if(highScore.contentEquals("null")) {

            getSupportFragmentManager().beginTransaction().replace(R.id.layout, new Login(), "Login").addToBackStack(null).commit();
        }
        else if(highScore==null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.layout, new Login(), "Login").addToBackStack(null).commit();


        }else
         {
            Expense_App expense_app=new Expense_App();
            Bundle bundle=new Bundle();
            bundle.putString("key",highScore);
            expense_app.setArguments(bundle);
             Log.d("demoqq","in main expense"+highScore);

             getSupportFragmentManager().beginTransaction().replace(R.id.layout, expense_app, "Login").addToBackStack(null).commit();

        }


    }






    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
         filePath=imageReturnedIntent.getData();
        Log.d("demo",filePath.toString());
        Intent intent=new Intent("fillter_data12");
        intent.putExtra("url",filePath.toString());
        LocalBroadcastManager.getInstance(MainActivity.this).sendBroadcast(intent);


    }
    public void onDateSet1(String key){
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }
    public void onDateSet2(String key){
        SharedPreferences sharedPref =this.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("key", "null");
        editor.commit();
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }

    public void onDateSet(String key) {
        SharedPreferences sharedPref =this.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("key", key);
        editor.commit();
//        editor.putString( "key", key); // Storing string
//        editor.apply();
//        editor.commit();
//        Toast.makeText(this, key, Toast.LENGTH_SHORT).show();
        Log.d("demo123",key);
        if(key=="null"){
            getSupportFragmentManager().beginTransaction().replace(R.id.layout, new Login(), "Login").addToBackStack(null).commit();

        }
        else {
            Expense_App expense_app=new Expense_App();
            Bundle bundle=new Bundle();
            bundle.putString("key",key);
            expense_app.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.layout, expense_app, "Login").addToBackStack(null).commit();

        }
    }
}
