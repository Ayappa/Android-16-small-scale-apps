package com.example.ayappa.imageviewer;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import static com.example.ayappa.imageviewer.R.drawable.noimage;

public class MainActivity extends AppCompatActivity {
StringBuilder stringUrl=new StringBuilder();
ArrayList<String> names=new ArrayList<String>();
    String string;
    int right=0;
    int size=0;
    Button buttonleft;
    Button buttonright;
    Spinner spinner;
   // ProgressBar pg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonleft=(Button)findViewById(R.id.button2);
       // pg=(ProgressBar)findViewById(R.id.progressBar);
       // pg.setVisibility(View.INVISIBLE);
        spinner = (Spinner)findViewById(R.id.spinner);
        spinner.setPrompt("Select one of the following");
        buttonleft.setEnabled(false);
         buttonright=(Button)findViewById(R.id.button3);
        buttonright.setEnabled(false);
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
    public void onClick(View v) {
        new connectionTest().execute();
                spinner.setSelection(0);

            }
      });

final Spinner spin=(Spinner)findViewById(R.id.spinner);
spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
      //  findViewById(R.id.progressBar).setVisibility(View.VISIBLE);

        String txt=spin.getSelectedItem().toString();
        String url="http://dev.theappsdr.com/apis/photos/index.php";
        string=txt;
        Async asy= new Async(0,MainActivity.this);
        asy.execute(txt);
        try {
           // Bitmap bm;
            asy.get();
            size=asy.size-1;
           if(size==0){buttonleft.setEnabled(false);
           buttonright.setEnabled(false);}
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
});

buttonright.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        right++;
        if(right>=size){right=0;}
        new Async(right,MainActivity.this).execute(string);
    }
});
buttonleft.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        right--;
        if(right<0){right=size-1;}
         new Async(right,MainActivity.this).execute(string);
    }
});

    }

    public class connectionTest extends AsyncTask<Void, Void, StringBuilder> {
        public boolean isNetworkAvailable() {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                return true;
            } else return false;
        }

        @Override
        protected void onPostExecute(StringBuilder s) {
            String[] strig = stringUrl.toString().split(";");
            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item, strig);
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spinnerAdapter);
            buttonleft.setEnabled(true);
            buttonright.setEnabled(true);
            stringUrl.delete(0,stringUrl.capacity());
            super.onPostExecute(s);

        }

        @Override
        protected StringBuilder doInBackground(Void... voids) {
            if (isNetworkAvailable()) {
                try {
                    URL url = new URL("http://dev.theappsdr.com/apis/photos/keywords.php");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.setRequestMethod("GET");
                    connection.connect();
                    BufferedReader input = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    if ((line=input.readLine()) != null) {
                    stringUrl.append(line);
                    }
                    String[] strig = stringUrl.toString().split(";");
                     input.close();
                     connection.disconnect();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return stringUrl;
        }


    }




}

