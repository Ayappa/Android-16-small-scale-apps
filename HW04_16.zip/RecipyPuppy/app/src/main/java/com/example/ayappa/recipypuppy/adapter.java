package com.example.ayappa.recipypuppy;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.support.v4.app.Fragment;
import android.widget.Toast;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.Fragment;

import java.util.ArrayList;

import static android.support.v7.widget.RecyclerView.*;

class adapter extends RecyclerView.Adapter<adapter.ViewHolder> {

    ArrayList<String> urlname=new ArrayList<String>() ;
    public adapter(ArrayList<String> urlname1) {
        this.urlname=urlname1;
        Log.d("demo1", "Constructor"+String.valueOf(this.urlname.size()));

    }

    public adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapterdisplay,viewGroup,false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }

    @Override

    public void onBindViewHolder(@NonNull final adapter.ViewHolder viewHolder,  int i) {
        final int position =i;
        Log.d("demo123","INBIND-before adding"+urlname.size());

        viewHolder.list_detailsArrayList=urlname;
        viewHolder.name.setText(urlname.get(i));
        if(position<urlname.size()-1){
            viewHolder.addButton.setVisibility(INVISIBLE);
            viewHolder.deleteButton.setVisibility(VISIBLE);
            viewHolder.name.setEnabled(false);

        }
        else{
            viewHolder.deleteButton.setVisibility(INVISIBLE);
            viewHolder.addButton.setVisibility(VISIBLE);
            viewHolder.name.setEnabled(true);



        }

        viewHolder.addButton.setOnClickListener(new OnClickListener() {
            private Context context;
            @Override
            public void onClick(View v) {
                if(position==5){
                    Toast.makeText(v.getContext(),"ONLY 5 INGREDIENTS POSSIBLE",Toast.LENGTH_LONG).show();
                }else {

                    if(viewHolder.name.getText().toString().contentEquals(" "))
                    {
                        Toast.makeText(v.getContext(),"Enter Ingredients to add",Toast.LENGTH_LONG).show();
                    }
                    else {
                        urlname.add(position, viewHolder.name.getText().toString());
                        notifyDataSetChanged();
                        viewHolder.addButton.setVisibility(INVISIBLE);
                        viewHolder.deleteButton.setVisibility(VISIBLE);
                        viewHolder.name.setEnabled(false);
                        StringBuilder url = new StringBuilder();
                        Bundle bundle = new Bundle();
                        url.append("i=");
                        for (int m = 1; m < urlname.size(); m++) {
                            url.append(urlname.get(m) + ",");
                        }
                        String httpUrl = (String) url.subSequence(0, url.length() - 1);
                        Log.d("demo123456", "position" + position);
                        Intent intent = new Intent("custom-message");
                        intent.putExtra("url", httpUrl);
                        intent.putStringArrayListExtra("list", urlname);
                        LocalBroadcastManager.getInstance(v.getContext()).sendBroadcast(intent);

                    }
                }

            }
        });
        viewHolder.deleteButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                urlname.remove(position);
                viewHolder.addButton.setVisibility(VISIBLE);
                viewHolder.deleteButton.setVisibility(INVISIBLE);
                Log.d("demo123456","position"+position);
                notifyDataSetChanged();
                StringBuilder url=new StringBuilder();
                Bundle bundle=new Bundle();
                url.append("i=");
                for(int m=1;m<urlname.size();m++){
                    url.append(urlname.get(m)+",");
                }
                String httpUrl= (String) url.subSequence(0,url.length()-1);
                Log.d("demo1234","url-nae"+httpUrl);
                Intent intent = new Intent("custom-message");
                intent.putExtra("url",httpUrl);
                intent.putStringArrayListExtra("list",urlname);
                LocalBroadcastManager.getInstance(v.getContext()).sendBroadcast(intent);


            }
        });

    }

    @Override

    public int getItemCount() {
        Log.d("demo12","cout"+ this.urlname.size());
        return urlname.size();

    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        EditText name;
        Button addButton;
        Button deleteButton;
        ArrayList<String> list_detailsArrayList=new ArrayList<String>();
        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            name=(EditText)itemView.findViewById(R.id.addname);
            addButton=(Button)itemView.findViewById(R.id.addSearch);
            deleteButton=(Button)itemView.findViewById(R.id.delete);

    }

    }

}






