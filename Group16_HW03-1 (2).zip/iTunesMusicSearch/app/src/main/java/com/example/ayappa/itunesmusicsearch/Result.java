package com.example.ayappa.itunesmusicsearch;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Result extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        Intent getIntent = getIntent();
        Bundle b=getIntent.getBundleExtra("key");
        final String Track=b.getString("Track");
        final String Album=b.getString("Album");
        final String Album_price=b.getString("Album_price");
        final String Artist=b.getString("Artist");
        final String Date=b.getString("Date");
        final String Genere=b.getString("Genere");
        final String image=b.getString("image");
        final String Price=b.getString("Price");

        TextView Track1=(TextView)findViewById(R.id.textView15);
        TextView Album1=(TextView)findViewById(R.id.textView23);
        TextView Album_price1=(TextView)findViewById(R.id.textView25);
        TextView Artist1=(TextView)findViewById(R.id.gravity);
        TextView Genere1=(TextView)findViewById(R.id.textView21);
        TextView Price1=(TextView)findViewById(R.id.textView24);

        Track1.setText(Track);
        Album1.setText(Album);
        Album_price1.setText(Album_price);
        Artist1.setText(Artist);
        Genere1.setText(Genere);
        Price1.setText(Price);
        new DownloadImage().execute(image);
        ProgressDialog progress1 = new ProgressDialog(getBaseContext());



        findViewById(R.id.button3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               finish();
            }
        });

    }



    public class DownloadImage extends AsyncTask<String, Void, Bitmap>{
        ProgressDialog progress1 = new ProgressDialog(Result.this);


        @Override
        protected void onPostExecute(Bitmap bitmap) {
            ImageView image=(ImageView)findViewById(R.id.imageView);
            image.setImageBitmap(bitmap);
            progress1.dismiss();

            super.onPostExecute(bitmap);
        }

        @Override
        protected void onPreExecute() {
            progress1.setMessage("Downloading Image..Please wait ");
            progress1.setProgressStyle(ProgressDialog.STYLE_SPINNER);
           // progress.setIndeterminate(true);
            progress1.show();

            super.onPreExecute();
        }

        @Override
        protected Bitmap doInBackground(String... strings) {
            try {
                URL url = new URL(strings[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.setRequestMethod("GET");
                connection.connect();
                InputStream input1 = connection.getInputStream();
                Bitmap myBitmap = BitmapFactory.decodeStream(input1);
               // myBitmap = Bitmap.createScaledBitmap(myBitmap, 100, 100, true);
              // myBitmap=Bitmap.createBitmap(myBitmap,0,0,400,400);
                return myBitmap;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }



}
