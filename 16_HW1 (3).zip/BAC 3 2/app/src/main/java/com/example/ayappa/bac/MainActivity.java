package com.example.ayappa.bac;

import android.content.res.Resources;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;


import static android.graphics.Color.CYAN;
import static android.graphics.Color.GREEN;
import static android.graphics.Color.RED;

public class MainActivity extends AppCompatActivity {
public String gender;
public Float weight;
public double bac_final;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button save=(Button)findViewById(R.id.button);
       final  Button reset=(Button)findViewById(R.id.button3);
       final Button calculate =(Button)findViewById(R.id.button2);
       final EditText name=(EditText)findViewById(R.id.editText);
       final ToggleButton rb=(ToggleButton)findViewById(R.id.toggleButton2);

        setTitle("BAC Calculator");
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.drawable.wine);

        save.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        //RadioGroup rg=(RadioGroup)findViewById(R.id.radioGroup3);
       // int name_val=Integer.parseInt(name.getText().toString());
        if(name.getText().length()==0 ){
            name.setError("Enter Valid Weight in lb");
            Toast.makeText(MainActivity.this,"enter valid input",Toast.LENGTH_LONG).show();
        }else if(Integer.parseInt(name.getText().toString())==0){ name.setError("Enter Valid Weight in lb");
            Toast.makeText(MainActivity.this,"enter valid input",Toast.LENGTH_LONG).show();}
        else {
            String gen= String.valueOf(rb.isChecked());
            if(rb.getText()=="F"){gender="F";}else{gender="M";}
            gender = (String) rb.getText();
            Log.d("demo","gender is ="+ gender);
            weight = Float.parseFloat(name.getText().toString());
            bac_final=0;
            save.setEnabled(false);
        }

    }
});

        SeekBar seek=(SeekBar)findViewById(R.id.seekBar);
         TextView seek_text=(TextView)findViewById(R.id.textView5);
        seek_text.setText("4");
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                TextView seek_text=(TextView)findViewById(R.id.textView5);
                seek_text.setText(String.valueOf(progress));

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

reset.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        EditText name=(EditText)findViewById(R.id.editText);
        name.setText(null);
        name.setHint("Enter your weight");
        rb.setChecked(true);
        RadioGroup rg1=(RadioGroup)findViewById(R.id.radioGroup);
        rg1.clearCheck();
        SeekBar seek=(SeekBar)findViewById(R.id.seekBar);
        seek.setProgress(4);
        TextView tx=(TextView)findViewById(R.id.textView9);
        tx.setText("BCA LEVEL : 0.00");
        ProgressBar pb=(ProgressBar)findViewById(R.id.progressBar2);
        pb.setProgress(4);
        TextView txstatus=(TextView)findViewById(R.id.textView11);
        txstatus.setText("Your Safe");
        txstatus.setBackgroundColor(GREEN);
        gender =null;
        weight= Float.valueOf(0);
        bac_final=0;
        save.setEnabled(true);
        calculate.setEnabled(true);


    }
});
calculate.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        RadioGroup rg1=(RadioGroup)findViewById(R.id.radioGroup);
        int rb_id1=rg1.getCheckedRadioButtonId();


        if( weight==null){ name.setError("Enter The Weight In Lbs");}
        else {
            save.setEnabled(false);
            double value;
            String male = "M";
            String female = "F";
            if (gender == male) {
                value = 0.68;
            } else {
                value = 0.55;
            }
            Log.d("demo", "value is :" + value);

            //ounce
            RadioButton rb1=(RadioButton)findViewById(rb_id1);
            String drink_size=rb1.getText().toString();
            int dvalue;
            if (drink_size.contentEquals("1 oz")) {
                dvalue = 1;
            } else if (drink_size.contentEquals("5 oz")) {
                dvalue = 5;
            } else {
                dvalue = 12;
            }
            Log.d("demo", "dvalue is :" + dvalue);

            //alcohol%
            SeekBar seek = (SeekBar) findViewById(R.id.seekBar);
            double seekpercent = seek.getProgress();
            seekpercent = seekpercent / 100;
            Log.d("demo", "seekvalue is :" + seekpercent);

            //calculate bac
            double bac = dvalue * seekpercent;
            double denom = weight * value;
            bac = bac * 6.24;
            bac = bac / denom;
            bac_final = bac_final + bac;
            TextView tx = (TextView) findViewById(R.id.textView9);
            tx.setText("BCA LEVEL :" + String.format("%.2f", bac_final));
            double bca_progress = bac_final * 100;
            String textresults;
            int color;
            TextView txt = (TextView) findViewById(R.id.textView11);
            if (bac_final <= 0.08) {
                textresults = "Your Safe";
                txt.setBackgroundColor(GREEN);
            } else if (bac_final > 0.08 && bac_final < 0.20) {
                textresults = "Be Carefull";
                txt.setBackgroundColor(CYAN);
            } else {
                textresults = "Your Over The Limit";
                txt.setBackgroundColor(RED);
                calculate.setEnabled(false);
            }
            ProgressBar pb1 = (ProgressBar) findViewById(R.id.progressBar2);
            pb1.setProgress((int) bca_progress);
            txt.setText(textresults);
        }

    }
});

    }
}
