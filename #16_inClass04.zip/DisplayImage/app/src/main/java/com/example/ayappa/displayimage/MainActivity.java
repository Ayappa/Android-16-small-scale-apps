package com.example.ayappa.displayimage;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

import static android.net.wifi.WifiConfiguration.Status.strings;

public class MainActivity extends AppCompatActivity {
    ImageView image;
    ProgressBar pro;
    Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        image = (ImageView) findViewById(R.id.imageView);
         pro = findViewById(R.id.progressBar);
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image.setVisibility(View.INVISIBLE);
                pro.setVisibility(View.VISIBLE);
                new DownloadImages().execute(" https://cdn.pixabay.com/photo/2014/12/16/22/25/youth-570881_960_720.jpg ");
            }
        });

        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image.setVisibility(View.INVISIBLE);
                pro.setVisibility(View.VISIBLE);
                handler=new Handler(new Handler.Callback() {
                    @Override
                    public boolean handleMessage(Message msg) {
                        Bitmap b=msg.getData().getParcelable("image");
                       // MyObject objectRcvd = (MyObject) msg.getData().getParcelable("IpTile");
                        image.setImageBitmap(b);
                    image.setVisibility(View.VISIBLE);
                           pro.setVisibility(View.INVISIBLE);
                        return true;
                    }
                });
                new Thread(new downloadThread()).start();
            }
        });
    }


    class DownloadImages extends AsyncTask<String, Void, Bitmap> {

        @Override
        protected Bitmap doInBackground(String... urls) {
            return download_Image(urls[0]);
        }

        @Override
        protected void onPostExecute(Bitmap result) {
            image.setImageBitmap(result);
            image.setVisibility(View.VISIBLE);
            pro.setVisibility(View.INVISIBLE);

        }


        private Bitmap download_Image(String url) {
            Bitmap bm = null;
            try {
                URL aurl = new URL(url);
                HttpURLConnection connection = (HttpURLConnection) aurl.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                 bm = BitmapFactory.decodeStream(input);
                return bm;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

     class downloadThread implements Runnable {

        @Override
        public void run() {
            //Bundle bun = new Bundle();
            Bitmap bm = null;
            try {
                URL aurl = new URL(" https://cdn.pixabay.com/photo/2017/12/31/06/16/boats-3051610_960_720.jpg ");
                HttpURLConnection connection = (HttpURLConnection) aurl.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                bm = BitmapFactory.decodeStream(input);
                Message msg = new Message();

                Bundle b = new Bundle();
                b.putParcelable("image",bm);
                msg.setData(b);

                handler.sendMessage(msg);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


}

