package com.example.ayappa.recipypuppy;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Display extends Fragment {




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        if (getArguments() != null) {
            //Log.d("url--",getArguments().get("url").toString());
        }
        return inflater.inflate(R.layout.secondfragment, container, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (getArguments() != null) {
           // Log.d("url--",getArguments().get("url").toString());
        }
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
         getActivity().setTitle("Recipes");
        if (getArguments() != null) {
            Log.d("url--",getArguments().get("url").toString());
            new getDetails().execute(getArguments().get("url").toString());
            setArguments(null);
            getView().findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getFragmentManager().popBackStack();
                }
            });
        }

    }

    public class getDetails extends AsyncTask<String, Integer,ArrayList<DisplayBean>> {
        ArrayList<DisplayBean>objects=new ArrayList<DisplayBean>();
int count=0;
int size;
ProgressBar progressBar;
TextView textView;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (isNetworkAvailable()==false) {
                Toast.makeText(getContext(), "NO INTERNET CONNECTION", Toast.LENGTH_LONG).show();
            }
            progressBar=getActivity().findViewById(R.id.progressBar2);
            textView=(TextView)getActivity().findViewById(R.id.load);
            textView.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.VISIBLE);

           // getFragmentManager().beginTransaction().replace(R.id.loading,new Loading(),"loading").addToBackStack(null).commit();
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(ArrayList<DisplayBean> displayBeans) {
            super.onPostExecute(displayBeans);
            textView.setVisibility(View.INVISIBLE);
            progressBar.setVisibility(View.INVISIBLE);

            if(objects.size()==0){Toast.makeText(getContext(),"NO Recipe Avaliable",Toast.LENGTH_LONG).show();            getFragmentManager().popBackStack();
            }else {
                RecyclerView recycle;
                RecyclerView.Adapter rAdapter;
                RecyclerView.LayoutManager rmanager;
                recycle = getView().findViewById(R.id.recycleSecond);
                recycle.setHasFixedSize(true);
                rmanager = new LinearLayoutManager(getView().getContext());
                recycle.setLayoutManager(rmanager);
                rAdapter = new displayAdapter(objects);
                recycle.setAdapter(rAdapter);
                for (int o = 0; o <= 10000000; o++) {
                }
            }

        }
        public boolean isNetworkAvailable() {
            ConnectivityManager connectivityManager = (ConnectivityManager)getContext().getSystemService(getContext().CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                return true;
            } else return false;

        }
        @Override
        protected ArrayList doInBackground(String... strings) {

                try {
                    URL url = new URL(strings[0]);
                    Log.d("display1", String.valueOf(url));
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.setRequestMethod("GET");
                    connection.connect();
                    String tags = IOUtils.toString(connection.getInputStream(), "UTF-8");
                    connection.disconnect();
                    String title;
                    String imageUrl;
                    String ingredients;
                    String httpUrl;
                    JSONObject urlName = new JSONObject(tags);
                    JSONArray result = urlName.getJSONArray("results");
                    int length = result.length();
                    size = length;
                    progressBar.setMax(length-1);
                    for (int i = 0; i < length; i++) {
                        progressBar.setProgress(i);
                        JSONObject disply1 = result.getJSONObject(i);
                        title = disply1.getString("title");
                        imageUrl = disply1.getString("thumbnail");
                        if (imageUrl.length() == 0) {
                            imageUrl = "https://smhttp-ssl-50970.nexcesscdn.net/media/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/placeholder/default/no_image_available_3.jpg";
                        }
                        ingredients = disply1.getString("ingredients");
                        httpUrl = disply1.getString("href");
                        DisplayBean displayBean = new DisplayBean(title, imageUrl, ingredients, httpUrl);
                        objects.add(displayBean);
                        count++;
                    }

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                return null;
            }

    }



    }
