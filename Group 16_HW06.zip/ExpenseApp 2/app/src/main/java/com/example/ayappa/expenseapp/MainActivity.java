package com.example.ayappa.expenseapp;


//Assignment number =HW5
//Names:Amith Yarra
//      Ayappa Krishnappa
//      Shashank Chandreshaker


import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    ArrayList<list_details> objects=new ArrayList<list_details>();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("expense");
    String name1;
    String amount1;
    String date1;
    Object image1;
    Bitmap imageBitmap;
    FirebaseStorage storage;
    StorageReference storageReference;
    private Uri filePath=null;
    String Storage_Path = "All_Image_Uploads/";
    String Database_Path = "All_Image_Uploads_Database";
    String imageurl;
    TextView txt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         // txt1= (TextView) findViewById(R.id.Total);

        Intent intent=new Intent();
        if(getIntent().getStringExtra("key")==null){
            Bundle bundle = new Bundle();
            String name1 = "name";
            bundle.putString("name", name1);
            Expense_App fragInfo = new Expense_App();
            fragInfo.setArguments(bundle);
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            if (user != null) {
                getSupportFragmentManager().beginTransaction().replace(R.id.layout, new Expense_App(), "Login").addToBackStack(null).commit();

            }else{
                getSupportFragmentManager().beginTransaction().replace(R.id.layout, new Login(), "Login").addToBackStack(null).commit();

            }



        }else {
               int position= Integer.parseInt(getIntent().getStringExtra("key"));
            Toast.makeText(MainActivity.this,"in main activity position="+position,Toast.LENGTH_LONG).show();
        }

    }






    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
         filePath=imageReturnedIntent.getData();
        Log.d("demo",filePath.toString());
        Intent intent=new Intent("fillter_data12");
        intent.putExtra("url",filePath.toString());
        LocalBroadcastManager.getInstance(MainActivity.this).sendBroadcast(intent);


    }







}
