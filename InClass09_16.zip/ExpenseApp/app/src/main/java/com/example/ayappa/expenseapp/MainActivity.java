package com.example.ayappa.expenseapp;


//Assignment number =HW5
//Names:Amith Yarra
//      Ayappa Krishnappa
//      Shashank Chandreshaker


import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements Expense_App.OnFragmentInteractionListener,addIteam.OnFragmentInteractionListener{
    ArrayList<list_details> objects=new ArrayList<list_details>();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("expense");
    String name1;
    String amount1;
    String date1;
    Object image1;
    Bitmap imageBitmap;
    FirebaseStorage storage;
    StorageReference storageReference;
    private Uri filePath=null;
    String Storage_Path = "All_Image_Uploads/";
    String Database_Path = "All_Image_Uploads_Database";
    String imageurl;
    TextView txt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         // txt1= (TextView) findViewById(R.id.Total);

        Intent intent=new Intent();
        if(getIntent().getStringExtra("key")==null){
            Bundle bundle = new Bundle();
            String name1 = "name";
            bundle.putString("name", name1);
            Expense_App fragInfo = new Expense_App();
            fragInfo.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.layout, new Login(), "Login").addToBackStack(null).commit();

        }else {
               int position= Integer.parseInt(getIntent().getStringExtra("key"));
            Toast.makeText(MainActivity.this,"in main activity position="+position,Toast.LENGTH_LONG).show();
        }

    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.game_menu, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case R.id.new_game:
//                //newGame();
//                return true;
//            case R.id.help:
//                // showHelp();
//                return true;
//            case R.id.help1:
//                // showHelp();
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//    }

    @Override
    public void onFragmentInteraction() {
        getSupportFragmentManager().beginTransaction().replace(R.id.layout,new addIteam(),"secong").addToBackStack(null).commit();


    }

    @Override
    public void onFragmentInteraction2(String name, String cat, String amount) {

    }
    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
          imageBitmap=(Bitmap)imageReturnedIntent.getExtras().get("data");
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();
        StorageReference storageReference;
        DatabaseReference databaseReference;
        storageReference = FirebaseStorage.getInstance().getReference();
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();
        final String key=myRef.push().getKey();
        final StorageReference storageReference2nd = storageReference.child(key);
        UploadTask uploadTask = storageReference2nd.putBytes(data);
        Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if (!task.isSuccessful()) {
                    throw task.getException();
                }
                Log.d("demo123q1---return", String.valueOf(storageReference2nd.getDownloadUrl()));

                // Continue with the task to get the download URL
                return storageReference2nd.getDownloadUrl();
            }
        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                if (task.isSuccessful()) {
                    Uri downloadUri = task.getResult();
                   imageurl=downloadUri.toString();
                    Log.d("demo123",downloadUri.toString());
                    Intent intent=new Intent("fillter_data12");
                    intent.putExtra("url",downloadUri.toString());
                    Log.d("demo123",imageurl);

                    LocalBroadcastManager.getInstance(MainActivity.this).sendBroadcast(intent);

                } else {
                    // Handle failures
                    // ...
                }
            }
        });





    }







}
