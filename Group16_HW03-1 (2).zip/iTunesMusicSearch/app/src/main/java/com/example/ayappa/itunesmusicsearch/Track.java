package com.example.ayappa.itunesmusicsearch;

public class Track {
    public String Track;
    public String Artist;
    public String Price;
    public String Date;
    public String Genere;
    public String Album_price;
    public String Album;
    public String image;

    public Track(String track, String artist, String price, String date, String genere, String album_price, String album, String image) {
        Track = track;
        Artist = artist;
        Price = price;
        Date = date;
        Genere = genere;
        Album_price = album_price;
        Album = album;
        this.image = image;
    }
}
