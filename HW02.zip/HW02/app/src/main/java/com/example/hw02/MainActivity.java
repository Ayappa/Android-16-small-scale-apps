package com.example.hw02;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button add_topping;
    private Button clear_pizza;
    private Button check_out;
    private ImageView pizza;
    private TextView viewToppings;
    private ImageView bacon ;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("PIZZA STORE");


        // assigning

        add_topping = findViewById(R.id.button_addToppings);
        clear_pizza = findViewById(R.id.button_clearPizza);
        check_out = findViewById(R.id.button_checkOut);
        pizza= findViewById(R.id.imageView_pizza);
        viewToppings= findViewById(R.id.textView_topping);
       final String[] toppings = getResources().getStringArray(R.array.toppings);
        final ImageView imageView = new ImageView(this);
      // grid layout
        final GridLayout gridLayout  = (GridLayout)findViewById(R.id.gridLayout);
        gridLayout.setColumnCount(5);
        gridLayout.setRowCount(4);
        add_topping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // creating alert dialog

                AlertDialog.Builder mBuilder = new AlertDialog.Builder(MainActivity.this);
                mBuilder.setTitle("Choose A Topping");

                //

                mBuilder.setSingleChoiceItems(toppings, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        viewToppings.setText(toppings[i]);
                        dialogInterface.dismiss();
                    }
                });

                AlertDialog mDialog = mBuilder.create();
                mDialog.show();

                switch (viewToppings.getText().toString()) {
                    case "Bacon":

                        gridLayout.removeView(imageView);
                        imageView.setImageResource(R.drawable.bacon);
                        gridLayout.addView(imageView);

               /*    case "Cheese" :
                        gridLayout.removeView(imageView);
                        imageView.setImageResource(R.drawable.cheese);
                        gridLayout.addView(imageView,1);


                    case "Garlic" :
                        gridLayout.removeView(imageView);
                        imageView.setImageResource(R.drawable.garlic);
                        gridLayout.addView(imageView,2);

                    case "Green Pepper" :
                        gridLayout.removeView(imageView);
                        imageView.setImageResource(R.drawable.green_pepper);
                        gridLayout.addView(imageView,3);

                    case "Olivs" :
                        gridLayout.removeView(imageView);
                        imageView.setImageResource(R.drawable.olive);
                        gridLayout.addView(imageView,4);

                    case "Onions" :
                        gridLayout.removeView(imageView);
                        imageView.setImageResource(R.drawable.onion);
                        gridLayout.addView(imageView,5);

                    case "Red Pepper" :
                        gridLayout.removeView(imageView);
                        imageView.setImageResource(R.drawable.red_pepper);
                        gridLayout.addView(imageView,6);

                    case "Mashroom" :
                        gridLayout.removeView(imageView);
                        imageView.setImageResource(R.drawable.mashroom);
                        gridLayout.addView(imageView,7);

                */







                }
            }
        });

    }





}
