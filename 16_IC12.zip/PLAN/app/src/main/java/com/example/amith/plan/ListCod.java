package com.example.amith.plan;


import android.content.Intent;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;

class ListCod extends RecyclerView.Adapter<ListCod.ViewHolder> {
        ArrayList<PojoPlace> detailsObjects;
        public ListCod(ArrayList<PojoPlace> detailsObjects) {
            this.detailsObjects=detailsObjects;
        }
        @NonNull
        @Override
        public ListCod.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.show,viewGroup,false);
            ViewHolder viewHolder=new ViewHolder(view);
            return viewHolder;
        }
        @Override
        public void onBindViewHolder(@NonNull ListCod.ViewHolder viewHolder, int i) {
            PojoPlace trip=detailsObjects.get(i);
            viewHolder.TripNAme.setText((CharSequence) trip.name);
            viewHolder.TripDate.setText((CharSequence) trip.date);
            viewHolder.Tripcity.setText((CharSequence) trip.city);
            //viewHolder.PlaceNAme.setText((CharSequence) trip.Dname.get(i));
            viewHolder.Info=trip;
        }
        @Override
        public int getItemCount() {
            return detailsObjects.size();
        }
        public static class ViewHolder extends RecyclerView.ViewHolder{
            TextView TripNAme;
            TextView TripDate;
            TextView Tripcity;
            TextView PlaceNAme;

            PojoPlace Info;
            public ViewHolder(@NonNull final View itemView) {
                super(itemView);
                TripNAme=(TextView)itemView.findViewById(R.id.TripName);
                TripDate=(TextView)itemView.findViewById(R.id.date);
                Tripcity=(TextView)itemView.findViewById(R.id.city);
                PlaceNAme=(TextView)itemView.findViewById(R.id.PlaceNAme);


                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent=new Intent(itemView.getContext(),MapsActivity.class);
                        intent.putExtra("key",Info.keys);
                        v.getContext().startActivity(intent);
                    }
                });

            }

        }

    }













