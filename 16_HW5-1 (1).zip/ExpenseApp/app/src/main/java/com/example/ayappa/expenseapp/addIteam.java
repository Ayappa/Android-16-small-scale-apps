package com.example.ayappa.expenseapp;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link addIteam.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link addIteam#newInstance} factory method to
 * create an instance of this fragment.
 */
public class addIteam extends Fragment implements  DatePickerFrag.DatePickerFragmentListener {
 Date date1;
    TextView textView;
    ImageView imageView;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("expense");
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public addIteam() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment addIteam.
     */
    // TODO: Rename and change types and number of parameters
    public static addIteam newInstance(String param1, String param2) {
        addIteam fragment = new addIteam();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_add_iteam, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }




    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction2(String name,String cat,String amount);
    }

    @Override
    public void onDateSet(Date date) {
       date1=date;

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().setTitle("Add Expense");
//        final Spinner spin =(Spinner)getView().findViewById(R.id.spinner3);
//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getView().getContext(), android.R.layout.simple_spinner_item, options);
//        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spin.setAdapter(adapter);
        final EditText ed=getView().findViewById(R.id.editText3);
        final EditText ed2=getView().findViewById(R.id.editText4);
       imageView=getView().findViewById(R.id.Rimage);
        getView().findViewById(R.id.button5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().popBackStack();
            }
        });
       textView=(TextView) getView().findViewById(R.id.date);

         //getView().findViewById(R.id.add)
        getView().findViewById(R.id.button4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ed.getText().toString().length()<=0){Toast.makeText(getView().getContext(),"Enter Valid Name",Toast.LENGTH_LONG).show(); }
              // else if(spin.getSelectedItem().toString().equals("Enter Choose")){Toast.makeText(getView().getContext(),"Select a category",Toast.LENGTH_LONG).show(); }
              else  if(ed2.getText().toString().length()<=0){Toast.makeText(getView().getContext(),"Enter Valid amount",Toast.LENGTH_LONG).show(); }
              else if(textView.getText().length()==0){
                    Toast.makeText(getView().getContext(), "Pick a Date", Toast.LENGTH_SHORT).show();
                }
                  else {
                    Date currentTime = Calendar.getInstance().getTime();
                    SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                    String d = df.format(currentTime);
                    //cat = spin.getSelectedItem().toString();
                   // int catno=spin.getSelectedItemPosition();
                   // Log.d("key123","cat_addIteam=="+catno);

                    String name = ed.getText().toString();
                    String amount = ed2.getText().toString();

                    String name1 = name;
                    String amount1 = amount;
                   // String date1 = d;
                    //list_details obj = new list_details(name, cat, amount, d,1);
                    // objects.add(obj);
                   // String key=myRef.push().getKey();
                   // myRef.child(key).setValue(obj);

                    ((MainActivity)getActivity()).onDataAll(name,amount); // <---- pass value to activity

                   getFragmentManager().popBackStack();
                }

            }
        });


        getView().findViewById(R.id.pick).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment newFragment = new DatePickerFrag();
                newFragment.show(getActivity().getSupportFragmentManager(), "datePicker");
                LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(getContext());
                lbm.registerReceiver(receiver, new IntentFilter("filter_date"));

            }
        });


        getView().findViewById(R.id.cimage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment newFragment = new FireMissilesDialogFragment();
                newFragment.show(getActivity().getSupportFragmentManager(), "datePicker");
                LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(getContext());
                lbm.registerReceiver(receiver1, new IntentFilter("filter_date12"));
            }
        });

    }

    public BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                String str = intent.getStringExtra("date");
                textView.setText(str);
            }
        }
    };
    public BroadcastReceiver receiver1 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                Uri  filePath= Uri.parse(intent.getStringExtra("image"));
                imageView.setImageURI(filePath);

            }
        }
    };


}


@SuppressLint("ValidFragment")
class FireMissilesDialogFragment extends DialogFragment {
    @SuppressLint("ResourceType")
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final CharSequence[] options = {"Take Photo", "Choose From Gallery","Cancel"};
        LayoutInflater layoutInflater = LayoutInflater.from(getContext());
        View promptView = layoutInflater.inflate(R.layout.imagechooser, null);
        // Use the Builder class for convenient dialog construction
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
    // Intent picture;

        Button button=(Button)promptView.findViewById(R.id.camera);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
               getActivity(). startActivityForResult(takePicture, 0);
               dismiss();
            }
        });
        Button galary=(Button)promptView.findViewById(R.id.galery);
        galary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Please Select Image"), 1);
                dismiss();
            }
        });
        builder. setPositiveButton("Always", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                //dialog.
            }
        })
                .setNegativeButton("JustOnce", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        builder.setView(promptView);
        return builder.create();
    }
}








@SuppressLint("ValidFragment")
class  DatePickerFrag extends DialogFragment implements DatePickerDialog.OnDateSetListener {
    int yr;
    int mon;
    int day;
    private DatePickerFragmentListener datePickerListener;

    public DatePickerFrag() {
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current date as the default date in the picker
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        // Create a new instance of DatePickerDialog and return it
        return new DatePickerDialog(getActivity(), this, year, month, day);
    }

    @Override
    public void onDateSet(android.widget.DatePicker view, int year, int month, int dayOfMonth) {
        Log.d("year124", String.valueOf(year));
        yr=year;
        mon=month;
        day=dayOfMonth;
        Calendar c = Calendar.getInstance();
        c.set(year, month, day);
        Date date = c.getTime();
        ((MainActivity)getActivity()).onDateSet(date); // <---- pass value to activity

    }


    public interface DatePickerFragmentListener {
        public void onDateSet(Date date);

    }

}



