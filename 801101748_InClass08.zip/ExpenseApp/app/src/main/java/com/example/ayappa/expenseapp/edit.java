package com.example.ayappa.expenseapp;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link edit.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link edit#newInstance} factory method to
 * create an instance of this fragment.
 */
public class edit extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    String[] options = {"Enter Choose","Groceries","invoice","Transportation",
            "Shopping","Rent","Trips","Utilities ","Other"};
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public edit() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment edit.
     */
    // TODO: Rename and change types and number of parameters
    public static edit newInstance(String param1, String param2) {
        edit fragment = new edit();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_edit, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
    }
    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final EditText name1=getView().findViewById(R.id.editText);
        final EditText amount1=getView().findViewById(R.id.editText2);
        final Spinner spinner=getView().findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getView().getContext(), android.R.layout.simple_spinner_item, options);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        String name=" ";
        String cat=" ";
        String amount= " ";
        String date =" ";
        String key =" ";
        int catNO=0;
        if (getArguments() != null) {
            name = getArguments().getString("name");
            cat = getArguments().getString("cat");
            amount = getArguments().getString("amount");
            date = getArguments().getString("Date");
            key=getArguments().getString("key");
            catNO=getArguments().getInt("catNo");
            name1.setText(name);
            amount1.setText(amount);
            spinner.setSelection(catNO);
            setArguments(null);
        }
        final String finalDate = date;
        final String finalKey1 = key;
        getView().findViewById(R.id.save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name1.getText().length() == 0) {
                    Toast.makeText(getContext(), "Enter Name", Toast.LENGTH_LONG).show();
                } else if (amount1.getText().length() == 0) {
                    Toast.makeText(getContext(), "Enter Amount", Toast.LENGTH_LONG).show();
                } else if (spinner.getSelectedItemPosition() == 0) {
                    Toast.makeText(getContext(), "Choose a category", Toast.LENGTH_LONG).show();
                } else {
                    String eName = name1.getText().toString();
                    String eamount = amount1.getText().toString();
                    String ecat = spinner.getSelectedItem().toString();
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = database.getReference().child("expense");
                    myRef.child(finalKey1).child("name").setValue(eName);
                    myRef.child(finalKey1).child("cat").setValue(ecat);
                    myRef.child(finalKey1).child("amount").setValue(eamount);
                    Bundle bundle = new Bundle();
                    bundle.putString("name", eName);
                    bundle.putString("cat", ecat);
                    bundle.putString("amount", eamount);
                    bundle.putString("Date", finalDate);
                    bundle.putString("key", finalKey1);
                    bundle.putInt("catNo", spinner.getSelectedItemPosition());
                    ShowFragment showFragment = new ShowFragment();
                    showFragment.setArguments(bundle);
                    getFragmentManager().beginTransaction().replace(R.id.layout, showFragment, "show").commit();
                }
            }
        });
        final String finalName = name;
        final String finalCat = cat;
        final String finalAmount = amount;
        final int finalCatNO = catNO;
        getView().findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Bundle bundle=new Bundle();
                bundle.putString("name", finalName);
                bundle.putString("cat", finalCat);
                bundle.putString("amount", finalAmount);
                bundle.putString("Date", finalDate);
                bundle.putString("key", finalKey1);
                bundle.putInt("catNo", finalCatNO);
                ShowFragment showFragment=new ShowFragment();
                showFragment.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.layout,showFragment,"show").commit();

            }
        });
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
