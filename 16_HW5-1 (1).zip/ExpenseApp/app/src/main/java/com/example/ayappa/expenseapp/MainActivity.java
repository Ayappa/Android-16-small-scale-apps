package com.example.ayappa.expenseapp;


//Assignment number =HW5
//Names:Amith Yarra
//      Ayappa Krishnappa
//      Shashank Chandreshaker


import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.MimeTypeMap;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


public class MainActivity extends AppCompatActivity implements Expense_App.OnFragmentInteractionListener,addIteam.OnFragmentInteractionListener{
    ArrayList<list_details> objects=new ArrayList<list_details>();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("expense");
    String name1;
    String amount1;
    String date1;
    Object image1;
    Bitmap imageBitmap;
    FirebaseStorage storage;
    StorageReference storageReference;
    private Uri filePath=null;
    String Storage_Path = "All_Image_Uploads/";
    String Database_Path = "All_Image_Uploads_Database";
    String imageurl;
    TextView txt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         // txt1= (TextView) findViewById(R.id.Total);

        Intent intent=new Intent();
        if(getIntent().getStringExtra("key")==null){
            Bundle bundle = new Bundle();
            String name1 = "name";
            bundle.putString("name", name1);
            Expense_App fragInfo = new Expense_App();
            fragInfo.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.layout, new Expense_App(), "first").addToBackStack(null).commit();

        }else {
               int position= Integer.parseInt(getIntent().getStringExtra("key"));
            Toast.makeText(MainActivity.this,"in main activity position="+position,Toast.LENGTH_LONG).show();
        }

    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.game_menu, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case R.id.new_game:
//                //newGame();
//                return true;
//            case R.id.help:
//                // showHelp();
//                return true;
//            case R.id.help1:
//                // showHelp();
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//    }

    @Override
    public void onFragmentInteraction() {
        getSupportFragmentManager().beginTransaction().replace(R.id.layout,new addIteam(),"secong").addToBackStack(null).commit();


    }

    @Override
    public void onFragmentInteraction2(String name, String cat, String amount) {

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
         filePath = imageReturnedIntent.getData();
        Intent intent = new Intent("filter_date12");
        intent.putExtra("image", filePath.toString());
         LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
        switch(requestCode) {
            case 0:
                if(resultCode == RESULT_OK){
                    Uri selectedImage = (Uri) imageReturnedIntent.getExtras().get("data");
                     imageBitmap = (Bitmap) imageReturnedIntent.getExtras().get("data");
                   // ImageView imageView=(ImageView)findViewById(R.id.imageView);
//                   // imageView.setImageBitmap(imageBitmap);
//                    Intent intent = new Intent("custom-image");
//                    // You can also include some extra data.
//                    intent.putExtra("message", imageReturnedIntent);
//                    LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
//                    Log.d("image123", "activy for imageReturnedIntent"+imageReturnedIntent.getExtras().get("data"));
//                    image1=imageReturnedIntent.getExtras().get("data");
                    filePath = imageReturnedIntent.getData();

                }
                break;
            case 1:
                if(resultCode == RESULT_OK){
//                    Uri selectedImage = (Uri) imageReturnedIntent.getExtras().get("data");
//                    Log.d("image123", "activy for imageReturnedIntent"+imageReturnedIntent.getExtras().get("data"));
//                    Intent intent = new Intent("custom-image");
//
//                    intent.putExtra("message", imageReturnedIntent);
//                    LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
//
//

                }

                break;
        }
    }

    public void onDateSet(Date date) {
        Date currentTime = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String d = df.format(date);
        Toast.makeText(this,"date"+d,Toast.LENGTH_LONG).show();
        date1=d;
        Intent intent = new Intent("filter_date");
        intent.putExtra("date", date1);
        // put your all data using put extra

        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);

    }

    public void onDataAll(String name, String amount) {
        name1=name;
        amount1=amount;
        if(filePath==null){
            final String key = myRef.push().getKey();

            list_details list_details1 = new list_details(name1, amount1, date1, null,key);
           // final String key = myRef.push().getKey();
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("expenseList");
            //final String key=myRef.push().getKey();
            myRef.child(key).setValue(list_details1);
        }else {

            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("expenseList");
            final String key = myRef.push().getKey();
            String path = key + ".jpg";

            StorageReference storageReference;
            DatabaseReference databaseReference;
            storageReference = FirebaseStorage.getInstance().getReference();
            final StorageReference storageReference2nd = storageReference.child(path);
            UploadTask uploadTask = storageReference2nd.putFile(filePath);


            Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw task.getException();
                    }
                    Log.d("demo123q1---return", String.valueOf(storageReference2nd.getDownloadUrl()));

                    // Continue with the task to get the download URL
                    return storageReference2nd.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful()) {
                        Uri downloadUri = task.getResult();
                        Log.d("demo123q1---issucess", String.valueOf(downloadUri));
                        list_details list_details1 = new list_details(name1, amount1, date1, String.valueOf(downloadUri),key);
                        ;
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference("expenseList");
                        //final String key=myRef.push().getKey();
                        myRef.child(key).setValue(list_details1);
                        Intent i=getIntent();

                        finish();

                        startActivity(i);

                    } else {
                        // Handle failures
                        // ...
                    }
                }
            });
        }

    }





    public String GetFileExtension(Uri uri) {

        ContentResolver contentResolver = getContentResolver();

        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();

        // Returning the file Extension.
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri)) ;

    }

    public void onDateSetEdit(Date date) {
        Date currentTime = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        String d = df.format(date);
        Toast.makeText(this,"date"+d,Toast.LENGTH_LONG).show();
        date1=d;
        Intent intent = new Intent("filter_date1");
        intent.putExtra("date", date1);
        // put your all data using put extra

        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);


    }

    public void onTotal(int total) {
       // txt1.setText(total);
    }
}
