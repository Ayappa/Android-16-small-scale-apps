package com.example.ayappa.expenseapp;

class list_details{

    String name;
    String email;
    String phone;
    Object image;
    String key;
list_details(){}
    public list_details(String name,  String email, String phone,  Object image,String key) {
        this.name = name;
       // this.cat = cat;
        this.email = email;
       this.phone = phone;
       this.image=image;
       this.key=key;
    }
}
