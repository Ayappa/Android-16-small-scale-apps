package com.example.ayappa.expenseapp;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Expense_App.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Expense_App#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Expense_App extends Fragment {
ArrayList<list_details> objects=new ArrayList<list_details>();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("messages");
     int total=0;

     Uri filepath;
    TextView name;
     TextView txt;
     EditText messgae;
     ImageView imageView;
     String keykey;
    String ResponseName;
     RecyclerView recycle;
    RecyclerView.Adapter rAdapter;
    RecyclerView.LayoutManager rmanager;


    private final OkHttpClient client = new OkHttpClient();

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    String Storage_Path = "All_Image_Uploads/";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public Expense_App() {
        // Required empty public constructor
    }




    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Expense_App.
     */
    // TODO: Rename and change types and number of parameters
    public static Expense_App newInstance(String param1, String param2) {
        Expense_App fragment = new Expense_App();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);

        }
        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        objects.clear();
        if (getArguments() != null) {

        }


        return inflater.inflate(R.layout.fragment_expense__app, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction();
    }



    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        name=(TextView)getView().findViewById(R.id.name);
       TextView name1=(TextView)getView().findViewById(R.id.textView);

        // messgae=(EditText)getView().findViewById(R.id.TextEnter);
        getActivity().setTitle("Contacts");
        txt= getView().findViewById(R.id.textView);
        objects.clear();
        recycle = getView().findViewById(R.id.recyle);
        recycle.setHasFixedSize(true);
        rmanager = new LinearLayoutManager(getView().getContext());
        recycle.setLayoutManager(rmanager);
//        try {
//            runRetriveData();
//            rAdapter = new Adapter(objects);
//            recycle.setAdapter(rAdapter);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        if (getArguments() != null) {
             keykey=getArguments().getString("key");
            Log.d("demoqq","in acvitycreated"+keykey);

            try {

                runRetriveData();
                run2();

                for(int i=0;i<100000;i++){ for(int ii=0;ii<10000;ii++){}}

                rAdapter = new Adapter(objects);
                recycle.setAdapter(rAdapter);
                Toast.makeText(getContext(), "after loop"+objects.size(), Toast.LENGTH_SHORT).show();
                // runRetriveData();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if(objects.size()==0) {
                name1.setText("No notes,add Notes to display");

            }else{name1.setText("");}
//            try {
//                runRetriveData();
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//
//            final RecyclerView recycle;
//            RecyclerView.Adapter rAdapter;
//            RecyclerView.LayoutManager rmanager;
//            recycle = getView().findViewById(R.id.recyle);
//            recycle.setHasFixedSize(true);
//            rmanager = new LinearLayoutManager(getView().getContext());
//            recycle.setLayoutManager(rmanager);
//            rAdapter = new Adapter(objects);
//            recycle.setAdapter(rAdapter);

        }
//        try {
//            runRetriveData();
//            rAdapter = new Adapter(objects);
//            recycle.setAdapter(rAdapter);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        getView().findViewById(R.id.AddNote).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddNote addNote=new AddNote();
                Bundle bundle=new Bundle();
                bundle.putString("key",keykey);
                addNote.setArguments(bundle);

                getFragmentManager().beginTransaction().replace(R.id.layout, addNote, "Login").addToBackStack(null).commit();

            }

        });

        getView().findViewById(R.id.logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    run();

                } catch (Exception e) {
                    e.printStackTrace();
                }

               // Toast.makeText(getContext(), "in ", Toast.LENGTH_SHORT).show();

            }
        });

    }
    public void runRetriveData() throws Exception {
       objects.clear();


        Request request = new Request.Builder()
                .url("http://ec2-3-91-77-16.compute-1.amazonaws.com:3000/api/note/getall")
                .addHeader("x-access-token",keykey)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override public void onResponse(Call call, Response response) throws IOException {
                try (ResponseBody responseBody = response.body()) {
                    if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

                    Headers responseHeaders = response.headers();
                    for (int i = 0, size = responseHeaders.size(); i < size; i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }
                    String jsonData = response.body().string();
                    JSONObject Jobject = new JSONObject(jsonData);
                    JSONArray notes= Jobject.getJSONArray("notes");
                    for(int Si=0;Si<notes.length();Si++){
                        JSONObject msg = notes.getJSONObject(Si);
                        String msg1=String.valueOf(msg.get("text"));
                        String id= String.valueOf(msg.get("userId"));
                        Log.d("demo1q", msg1);

                        list_details list_details1=new list_details(id,msg1,keykey);
                        objects.add(list_details1);

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

   public void set()
   {
       Toast.makeText(getContext(), "retrevied date"+objects.size(), Toast.LENGTH_SHORT).show();


   }    public void run2() throws Exception {

        Toast.makeText(getContext(), "run2", Toast.LENGTH_SHORT).show();

        Request request = new Request.Builder()
                .url("http://ec2-3-91-77-16.compute-1.amazonaws.com:3000/api/auth/me")
                .addHeader("x-access-token",keykey)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override public void onResponse(Call call, Response response) throws IOException {
                try (ResponseBody responseBody = response.body()) {
                    if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

                    Headers responseHeaders = response.headers();
                    for (int i = 0, size = responseHeaders.size(); i < size; i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }
                    String jsonData = response.body().string();
                    JSONObject Jobject = new JSONObject(jsonData);
                     ResponseName=Jobject.optString("name");
                     Log.d("demo1q", ResponseName);
                   name.setText("Hey "+ResponseName+"!!!");

                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public void run() throws Exception {


        Request request = new Request.Builder()
                .url("http://ec2-3-91-77-16.compute-1.amazonaws.com:3000/api/auth/logout")
                .build();

             client.newCall(request).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override public void onResponse(Call call, Response response) throws IOException {
                try (ResponseBody responseBody = response.body()) {
                    if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

                    Headers responseHeaders = response.headers();
                    for (int i = 0, size = responseHeaders.size(); i < size; i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }
                    String jsonData = response.body().string();
                    JSONObject Jobject = new JSONObject(jsonData);
                    Log.d("demo1", jsonData);
                    Log.d("demo1", Jobject.optString("token"));

                    String reaponseString=Jobject.optString("token");
                    ((MainActivity)getActivity()).onDateSet2(reaponseString);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }


}
