package com.example.ayappa.expenseapp;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


public class MainActivity extends AppCompatActivity implements Expense_App.OnFragmentInteractionListener,addIteam.OnFragmentInteractionListener{
    ArrayList<list_details> objects=new ArrayList<list_details>();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("expense");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent=new Intent();
        if(getIntent().getStringExtra("key")==null){
            Bundle bundle = new Bundle();
            String name1 = "name";
            bundle.putString("name", name1);
            Expense_App fragInfo = new Expense_App();
            fragInfo.setArguments(bundle);
            getSupportFragmentManager().beginTransaction().replace(R.id.layout, new Expense_App(), "first").addToBackStack(null).commit();

        }else {
               int position= Integer.parseInt(getIntent().getStringExtra("key"));
            Toast.makeText(MainActivity.this,"in main activity position="+position,Toast.LENGTH_LONG).show();
        }

    }


    @Override
    public void onFragmentInteraction() {
        getSupportFragmentManager().beginTransaction().replace(R.id.layout,new addIteam(),"secong").addToBackStack(null).commit();


    }

    @Override
    public void onFragmentInteraction2(String name, String cat, String amount) {

    }


}
