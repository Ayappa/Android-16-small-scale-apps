package com.example.ayappa.expenseapp;

import java.util.Date;

class list_details{

    String name;
    String cat;
    String amount;
    String currentTime;
    int catNO;
list_details(){}
    public list_details(String name, String cat, String amount, String currentTime,int catNO) {
        this.name = name;
        this.cat = cat;
        this.amount = amount;
       this.currentTime = currentTime;
       this.catNO=catNO;
    }
}
