package com.example.ayappa.recipypuppy;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

class displayAdapter extends RecyclerView.Adapter<displayAdapter.ViewHolder> {

    ArrayList<DisplayBean> displayBeans=new ArrayList<DisplayBean>() ;
    public displayAdapter(ArrayList<DisplayBean> displayBeans1) {
        this.displayBeans=displayBeans1;
        Log.d("demo1", "Constructor"+String.valueOf(this.displayBeans.size()));

    }
    @NonNull
    @Override
    public displayAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.fragment_display,viewGroup,false);
        displayAdapter.ViewHolder viewHolder=new displayAdapter.ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int i) {


        final DisplayBean displayBean=displayBeans.get(i);
        viewHolder.detailsArrayList=displayBeans;
        viewHolder.title.setText(displayBean.title);
        viewHolder.ingredients.setText(displayBean.ingredients);
        String text = "<a>"+ displayBean.httpUrl +"</a>";
       // textView.setText(Html.fromHtml(text));
        viewHolder.httpUrl.setText(Html.fromHtml(text));
        Log.d("12345",text);
        Picasso.with(viewHolder.context).load(displayBean.imageUrl).into(viewHolder.image);
        viewHolder.httpUrl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url=displayBean.httpUrl;
                Intent ii=new Intent(Intent.ACTION_VIEW);
                ii.setData(Uri.parse(url));
                viewHolder.context.startActivity(ii);

            }
        });

    }



    @Override
    public int getItemCount() {
        return displayBeans.size();
    }



    public static class ViewHolder extends RecyclerView.ViewHolder{

        TextView title;
        TextView ingredients;
        TextView httpUrl;
        ImageView image;
        Context context;

        ArrayList<DisplayBean> detailsArrayList=new ArrayList<DisplayBean>();
        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            title=(TextView) itemView.findViewById(R.id.textView4);
            ingredients=(TextView) itemView.findViewById(R.id.ingredients);
            httpUrl=(TextView) itemView.findViewById(R.id.urlhttp);
            image=(ImageView) itemView.findViewById(R.id.imageView);
             context=itemView.getContext();

        }

    }
}

