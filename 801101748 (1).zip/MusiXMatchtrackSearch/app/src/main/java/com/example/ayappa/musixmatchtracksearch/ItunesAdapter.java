package com.example.ayappa.musixmatchtracksearch;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

class ItunesAdapter extends RecyclerView.Adapter<ItunesAdapter.ViewHolder> {
    ArrayList<Track> detailsObjects;




    public ItunesAdapter(ArrayList<Track> detailsObjects) {
        this.detailsObjects=detailsObjects;

    }

    @NonNull
    @Override
    public ItunesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.display,viewGroup,false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ItunesAdapter.ViewHolder viewHolder, int i) {
        Track track=detailsObjects.get(i);
        viewHolder.TrackName.setText((CharSequence) track.track);
        viewHolder.ArtistName.setText((CharSequence) track.artist);
        viewHolder.AlbumName.setText((CharSequence) track.album);
        viewHolder.DateOf.setText((CharSequence) track.time);
        viewHolder.tunesInfo=track;

    }

    @Override
    public int getItemCount() {
        return detailsObjects.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView Track;
        TextView TrackName;
        TextView Artist;
        TextView ArtistName;
        TextView Album;
        TextView AlbumName;
        TextView Date;
        TextView DateOf;
        Track tunesInfo;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            Track=(TextView)itemView.findViewById(R.id.textView4);
            TrackName=(TextView)itemView.findViewById(R.id.textView5);
            Artist=(TextView)itemView.findViewById(R.id.textView8);
            ArtistName=(TextView)itemView.findViewById(R.id.textView9);
            Album=(TextView)itemView.findViewById(R.id.textView6);
            AlbumName=(TextView)itemView.findViewById(R.id.textView7);
            Date=(TextView)itemView.findViewById(R.id.textView10);
            DateOf=(TextView)itemView.findViewById(R.id.textView11);

           itemView.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   //String url = "http://www.example.com";
                   Intent i = new Intent(Intent.ACTION_VIEW);
                   i.setData(Uri.parse(tunesInfo.url));
                   itemView.getContext().startActivity(i);

               }
           });

        }
    }
}
