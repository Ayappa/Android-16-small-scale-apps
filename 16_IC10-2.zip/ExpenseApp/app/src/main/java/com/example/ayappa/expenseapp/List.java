package com.example.ayappa.expenseapp;

class list_details{

    String id;
    String message;
    String key;
list_details(){}
    public list_details(String id, String message,String key) {
        this.id = id;
        this.message=message;
        this.key=key;
       // this.cat = cat;

    }
}
