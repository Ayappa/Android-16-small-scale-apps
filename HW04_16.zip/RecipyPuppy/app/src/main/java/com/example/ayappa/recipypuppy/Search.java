package com.example.ayappa.recipypuppy;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;



public class Search extends Fragment {

ArrayList<String>urlname=new ArrayList<String>();
String urlName;
String address="http://www.recipepuppy.com/api/?";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         View view=inflater.inflate(R.layout.fragment_search, container, false);
        return view;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final EditText foodName=(EditText) getView().findViewById(R.id.foodname);
        RecyclerView.Adapter rAdapter;
        RecyclerView.LayoutManager rmanager;
        RecyclerView recycle;
        recycle = getView().findViewById(R.id.recycle);

        recycle.setHasFixedSize(true);
        rmanager = new LinearLayoutManager(getView().getContext());
        recycle.setLayoutManager(rmanager);
        if(urlname.size()<=0){        urlname.add(" "); }
        rAdapter = new adapter(urlname);
        recycle.setAdapter(rAdapter);
        LocalBroadcastManager.getInstance(getView().getContext()).registerReceiver(mMessageReceiver,
                new IntentFilter("custom-message"));
         final String fName=foodName.getText().toString();
        getView().findViewById(R.id.searchUrl).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(foodName.getText().length()==0){
                    Toast.makeText(getContext(), "Enter iteam name", Toast.LENGTH_LONG).show();

                }else {
                    String UrlAddress = address + urlName + "&q=" + foodName.getText().toString();
                    Bundle bundle = new Bundle();
                    bundle.putString("url", UrlAddress);
                    Display display = new Display();
                    display.setArguments(bundle);
                    getFragmentManager().beginTransaction().replace(R.id.search, display, "display").addToBackStack(null).commit();
                }
            }
        });
    }
    public BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
             urlName = intent.getStringExtra("url");
             urlname=intent.getStringArrayListExtra("list");
        }
    };
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }




}
