package com.example.ayappa.expenseapp;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.Date;

public class edit extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
     TextView dateText;
    private Uri filePath=null;
    ImageView imageView;

    String name=" ";
    String image=" ";
    String amount= " ";
    String date =" ";
    String key ;
    String imageurl;
    int flag=0;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    static final int PICK_CONTACT_REQUEST = 3;  // The request code

    private OnFragmentInteractionListener mListener;

    public static edit newInstance(String param1, String param2) {
        edit fragment = new edit();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_edit, container, false);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final EditText name1=getView().findViewById(R.id.editText);
        final EditText amount1=getView().findViewById(R.id.editText2);
         dateText=getView().findViewById(R.id.textView12);
         imageView=getView().findViewById(R.id.imageView3);


        if (getArguments() != null) {
            name = getArguments().getString("name");
            image = getArguments().getString("image");
            amount = getArguments().getString("amount");
            date = getArguments().getString("date");
            key=getArguments().getString("key");
            Log.d("image123q",getArguments().getString("key"));

            //catNO=getArguments().getInt("catNo");
            name1.setText(name);
            amount1.setText(amount);
            dateText.setText(date);
            Picasso.with(getContext()).load(image).into(imageView);
            setArguments(null);
        }
        final String finalDate = date;
        final String finalKey1 = key;

        getView().findViewById(R.id.pDate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment newFragment = new DatePickerFrag12();
                newFragment.show(getActivity().getSupportFragmentManager(), "datePicker1");
                LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(getContext());
                lbm.registerReceiver(receiver, new IntentFilter("filter_date1"));
            }
        });

        getView().findViewById(R.id.customimage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment newFragment = new FireMissilesDialogFragment();
                newFragment.show(getActivity().getSupportFragmentManager(), "datePicker1");
                LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(getContext());
                lbm.registerReceiver(receiver1, new IntentFilter("filter_date12"));
                flag=1;
            }
        });


        getView().findViewById(R.id.save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name1.getText().length() == 0) {
                    Toast.makeText(getContext(), "Enter Name", Toast.LENGTH_LONG).show();
                } else if (amount1.getText().length() == 0) {
                    Toast.makeText(getContext(), "Enter Amount", Toast.LENGTH_LONG).show();
                } else {
                    final String eName = name1.getText().toString();
                    final String eamount = amount1.getText().toString();

                    if(flag==0){
                        list_details list_details1 = new list_details(eName, eamount, date, image, finalKey1);
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference("expenseList");
                        myRef.child(key).setValue(list_details1);
                        getFragmentManager().popBackStack();

                    }
                    else {
                        StorageReference storageReference;
                        DatabaseReference databaseReference;
                        storageReference = FirebaseStorage.getInstance().getReference();
                        final StorageReference storageReference2nd = storageReference.child(finalKey1 + ".jpg");
                        UploadTask uploadTask = storageReference2nd.putFile(filePath);
                        Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                            @Override
                            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                                if (!task.isSuccessful()) {
                                    throw task.getException();
                                }
                                return storageReference2nd.getDownloadUrl();
                            }
                        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task) {
                                if (task.isSuccessful()) {
                                    Uri downloadUri = task.getResult();
                                    list_details list_details1 = new list_details(eName, eamount, date, String.valueOf(downloadUri), finalKey1);
                                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                                    DatabaseReference myRef = database.getReference("expenseList");
                                    myRef.child(key).setValue(list_details1);

                                    getFragmentManager().popBackStack();

                                } else {

                                }
                            }
                        });

                    }

                }
            }
        });
        final String finalName = name;
        final String finalAmount = amount;
        getView().findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle=new Bundle();
                bundle.putString("name", finalName);
                bundle.putString("amount", finalAmount);
                bundle.putString("Date", finalDate);
                bundle.putString("key", finalKey1);
                ShowFragment showFragment=new ShowFragment();
                showFragment.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.layout,showFragment,"show").commit();

            }
        });
    }
    public BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                String str = intent.getStringExtra("date");
                dateText.setText(str);
                date=str;

            }
        }
    };
    public BroadcastReceiver receiver1 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
               filePath= Uri.parse(intent.getStringExtra("image"));
               imageView.setImageURI(filePath);
                Log.d("image123q", String.valueOf(filePath));
                Log.d("image123q",key );
            }
        }
    };

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }


    @SuppressLint("ValidFragment")
   public static class FireMissilesDialogFragment extends DialogFragment {
        @SuppressLint("ResourceType")
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final CharSequence[] options = {"Take Photo", "Choose From Gallery", "Cancel"};
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            View promptView = layoutInflater.inflate(R.layout.imagechooser, null);
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            Button button = (Button) promptView.findViewById(R.id.camera);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    getActivity().startActivityForResult(takePicture, PICK_CONTACT_REQUEST);
                    dismiss();
                }
            });
            Button galary = (Button) promptView.findViewById(R.id.galery);
            galary.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    intent.putExtra("key","key");
                    startActivityForResult(Intent.createChooser(intent, "Please Select Image"), PICK_CONTACT_REQUEST);
                    dismiss();
                }
            });
            builder.setPositiveButton("Always", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                }
            })
                    .setNegativeButton("JustOnce", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            builder.setView(promptView);
            return builder.create();
        }

    }
        @SuppressLint("ValidFragment")
        public static class DatePickerFrag12 extends DialogFragment implements DatePickerDialog.OnDateSetListener {
            int yr;
            int mon;
            int day;
            private com.example.ayappa.expenseapp.DatePickerFrag.DatePickerFragmentListener datePickerListener;

            public DatePickerFrag12() {
            }

            @Override
            public Dialog onCreateDialog(Bundle savedInstanceState) {
                // Use the current date as the default date in the picker
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                // Create a new instance of DatePickerDialog and return it
                return new DatePickerDialog(getActivity(), this, year, month, day);
            }

            @Override
            public void onDateSet(android.widget.DatePicker view, int year, int month, int dayOfMonth) {
                Log.d("year124", String.valueOf(year));
                yr = year;
                mon = month;
                day = dayOfMonth;
                Calendar c = Calendar.getInstance();
                c.set(year, month, day);
                Date date = c.getTime();
                ((MainActivity) getActivity()).onDateSetEdit(date); // <---- pass value to activity

            }

        }
    }

