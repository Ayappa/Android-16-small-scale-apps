package com.example.ayappa.expenseapp;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link addIteam.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link addIteam#newInstance} factory method to
 * create an instance of this fragment.
 */
public class addIteam extends Fragment {
    String[] options = {"Enter Choose","Groceries","invoice","Transportation",
            "Shopping","Rent","Trips","Utilities ","Other"};
    String cat;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("expense");
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public addIteam() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment addIteam.
     */
    // TODO: Rename and change types and number of parameters
    public static addIteam newInstance(String param1, String param2) {
        addIteam fragment = new addIteam();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_add_iteam, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction2(String name,String cat,String amount);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().setTitle("Add Expense");
        final Spinner spin =(Spinner)getView().findViewById(R.id.spinner3);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getView().getContext(), android.R.layout.simple_spinner_item, options);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(adapter);
        final EditText ed=getView().findViewById(R.id.editText3);
        final EditText ed2=getView().findViewById(R.id.editText4);

        getView().findViewById(R.id.button5).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().popBackStack();
            }
        });

         //getView().findViewById(R.id.add)
        getView().findViewById(R.id.button4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ed.getText().toString().length()<=0){Toast.makeText(getView().getContext(),"Enter Valid Name",Toast.LENGTH_LONG).show(); }
               else if(spin.getSelectedItem().toString().equals("Enter Choose")){Toast.makeText(getView().getContext(),"Select a category",Toast.LENGTH_LONG).show(); }
              else  if(ed2.getText().toString().length()<=0){Toast.makeText(getView().getContext(),"Enter Valid amount",Toast.LENGTH_LONG).show(); }
                  else {
                    Date currentTime = Calendar.getInstance().getTime();
                    SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                    String d = df.format(currentTime);
                    cat = spin.getSelectedItem().toString();
                    int catno=spin.getSelectedItemPosition();
                    Log.d("key123","cat_addIteam=="+catno);

                    String name = ed.getText().toString();
                    String amount = ed2.getText().toString();

                    String name1 = name;
                    String cat1 = cat;
                    String amount1 = amount;
                    String date1 = d;
                    list_details obj = new list_details(name, cat, amount, d,catno);
                    // objects.add(obj);
                    String key=myRef.push().getKey();
                    myRef.child(key).setValue(obj);


                   getFragmentManager().popBackStack();
                }

            }
        });






    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



    }
}
