package com.example.ayappa.bmi;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

import static java.sql.Types.FLOAT;
import static java.sql.Types.NULL;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
setTitle("BMI CALCULATOR");


        Button button = findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int w = 0, f = 0, n = 0;
                TextView res = findViewById(R.id.result1);
                TextView res1 = findViewById(R.id.result2);
                EditText weight1 = (EditText) findViewById(R.id.editText5);
                if (weight1.length() == 0) {
                    w = 1;
                    Toast.makeText(getApplicationContext(), "enter  valid weight", Toast.LENGTH_LONG).show();
                }

                EditText height_ft1 = findViewById(R.id.editText3);
                if (height_ft1.length() == 0) {
                    f = 1;
                    Toast.makeText(getApplicationContext(), "enter valid height in feet", Toast.LENGTH_LONG).show();
                }
                EditText height_in1 = findViewById(R.id.editText4);
                if (height_in1.length() == 0) {
                    n = 1;
                    Toast.makeText(getApplicationContext(), "enter valid height in in ", Toast.LENGTH_LONG).show();
                }

                if (w == 1 || f == 1 || n == 1) {

                    Toast.makeText(getApplicationContext(), "enter valid input ", Toast.LENGTH_LONG).show();
                    res.setText("YOUR BMI: -" );
                    res1.setText("Enter your Details to show results");


                } else {
                    float weight = Float.parseFloat (weight1.getText().toString());
                    int height_ft = Integer.parseInt(height_ft1.getText().toString());
                    int height_in = Integer.parseInt(height_in1.getText().toString());
                    height_ft = height_ft * 12;
                    int total_height = height_ft + height_in;
                    float bmi = 0;
                    bmi = total_height * total_height;
                    bmi = weight / bmi;
                    bmi = bmi * 703;
                    DecimalFormat df = new DecimalFormat("#.##");
                    bmi=Float.parseFloat(df.format(bmi));
                    res.setText("YOUR BMI:" + bmi);
                    String result;
                    if (bmi <= 18.5) {
                        result = "You are underweight";
                    } else if (bmi > 18.5 && bmi <= 24.5) {
                        result = "You are normal";
                    } else if (bmi > 25 && bmi <= 29.9) {
                        result = "You are overweight";
                    } else {
                        result = "You are obese";
                    }
                    res1.setText(result);


                }
            }

        });


    }
}