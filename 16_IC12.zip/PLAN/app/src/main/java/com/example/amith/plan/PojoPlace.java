package com.example.amith.plan;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class PojoPlace  {
    public  String name;
    public String city;
    public String placeName;
    public ArrayList<String> Dname;
    public ArrayList<Double>lat;
    public ArrayList<Double>lag;
   // String lat;
    //String lag;
   public String date;
    public Double citylat;
    public Double citylag;
    public String keys;


    public PojoPlace(String name, String city, String placeName, ArrayList<String> dname, ArrayList<Double> lat, ArrayList<Double> lag, String date, Double citylat, Double citylag, String  keys) {
        this.name = name;
        this.city = city;
        this.placeName = placeName;
       this. Dname = dname;
        this.lat = lat;
        this.lag = lag;
        this.date = date;
        this.citylat = citylat;
        this.citylag = citylag;
        this.keys = keys;
    }

PojoPlace(){}


//    protected PojoPlace(Parcel in){
//        this.name = in.readString();
//        this.city = in.readString();
//        this.placeName =  in.readString();
//       this. Dname =  in.readString();
//        this.lat = in.readList();
//        this.lag = lag;
//        this.date =  in.readString();
//        this.citylat =  in.readString();
//        this.citylag =  in.readString();
//        this.keys =  in.readString();
//    }
//
//    @Override
//    public int describeContents() {
//        return 0;
//    }
// public  static final Creator<PojoPlace> CREATOR=new Creator<PojoPlace>() {
//     @Override
//     public PojoPlace createFromParcel(Parcel source) {
//         return null;
//     }
//
//     @Override
//     public PojoPlace[] newArray(int size) {
//         return new PojoPlace[0];
//     }
// };
//    @Override
//    public void writeToParcel(Parcel dest, int flags) {
//        dest.writeString(this.name);
//        dest.writeString(this.city);
//        dest.writeString(this.placeName);
//        dest.writeString(this.Dname);
//        dest.writeList(this.lat);
//        dest.writeList(this.lag);
//        dest.writeString(this.date);
//        dest.writeString(this.citylat);
//        dest.writeString(this.citylag);
//        dest.writeString(this.keys);
//
//
//
//    }
}
