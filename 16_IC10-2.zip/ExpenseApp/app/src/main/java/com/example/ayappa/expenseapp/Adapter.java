package com.example.ayappa.expenseapp;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
         Context context;
    private final OkHttpClient client = new OkHttpClient();

    ArrayList<list_details> detailsObjects;
        public Adapter(ArrayList<list_details> detailsObjects) {
            this.detailsObjects=detailsObjects;
        }

        public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.show,viewGroup,false);
            ViewHolder viewHolder=new ViewHolder(view);
           context= viewGroup.getContext();
            return viewHolder;
        }

        @Override

        public void onBindViewHolder(@NonNull Adapter.ViewHolder viewHolder, int i) {
            list_details details=detailsObjects.get(i);
            String message=details.message;
            if(message.length()>25) {
                message = message.substring(0, 25);
                message=message+"...";
            }
            viewHolder.messgae.setText(message);

            viewHolder.heading.setText( "NOTE "+i+1+" :");

            viewHolder.list_detailsArrayList=detailsObjects;
            viewHolder.position=i;
            viewHolder.details1=details;
            viewHolder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   detailsObjects.remove(i);
                    notifyItemRemoved(i);








                }
            });

        }

        @Override

        public int getItemCount() {

            return detailsObjects.size();

        }

        public static class ViewHolder extends RecyclerView.ViewHolder{

            TextView messgae;
            TextView heading;
            Button delete;
            OnFragmentInteractionListener mListerner;
            private final OkHttpClient client = new OkHttpClient();

            public interface OnFragmentInteractionListener {
                // TODO: Update argument type and name
                void onFragmentInteraction(int position);
            }


            ArrayList<list_details> list_detailsArrayList=new ArrayList<list_details>();
            list_details details1;
            private int position;

            public ViewHolder(@NonNull final View itemView) {

                super(itemView);
                messgae = (TextView) itemView.findViewById(R.id.message);
                heading = (TextView) itemView.findViewById(R.id.heading);
                delete = (Button) itemView.findViewById(R.id.del);


                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Dispaly expense_app = new Dispaly();
                        Bundle bundle = new Bundle();
                        bundle.putString("key", details1.key);

                        bundle.putString("msg", details1.message);
                        expense_app.setArguments(bundle);
                        Object context = itemView.getContext();
                        FragmentManager manager = ((AppCompatActivity) context).getSupportFragmentManager();


                        manager.beginTransaction().replace(R.id.layout, expense_app, "expense").addToBackStack(null).commit();

                    }
                });


                delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                       list_detailsArrayList.remove(position);

                       notifyAll();


                        Request request = new Request.Builder()
                                .url("http://ec2-3-91-77-16.compute-1.amazonaws.com:3000/api/note/delete?msgId="+details1.id)
                                .addHeader("x-access-token",details1.key)
                                .addHeader("Content-Type","application/x-www-form-urlencoded")
                                .build();

                        Log.d("url1","http://ec2-3-91-77-16.compute-1.amazonaws.com:3000/api/note/delete?msgId="+details1.id);

                        Log.d("url1",details1.key);
                        client.newCall(request).enqueue(new Callback() {
                            @Override public void onFailure(Call call, IOException e) {
                                e.printStackTrace();
                                Toast.makeText(v.getContext(), (CharSequence) e, Toast.LENGTH_SHORT).show();


                            }

                            @Override public void onResponse(Call call, Response response) throws IOException {
                                try (ResponseBody responseBody = response.body()) {
                                    if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

                                    Headers responseHeaders = response.headers();
                                    for (int i = 0, size = responseHeaders.size(); i < size; i++) {
                                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                                    }
                                    Toast.makeText(v.getContext(), responseBody.string(), Toast.LENGTH_SHORT).show();

//                                    Intent i = getActivity().getBaseContext().getPackageManager()
//                                            .getLaunchIntentForPackage(getActivity().getBaseContext().getPackageName());
//                                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                                    startActivity(i);
                                               Log.d("url12",responseBody.string());
//                            Expense_App expense_app=new Expense_App();
//                            Bundle bundle=new Bundle();
//                            bundle.putString("key",details1.key);
//                            expense_app.setArguments(bundle);
                                    Object context = itemView.getContext();
                                    FragmentManager manager = ((AppCompatActivity) context).getSupportFragmentManager();


                                    manager.beginTransaction().replace(R.id.layout,  new Dispaly(), "expense").addToBackStack(null).commit();

                                }
                            }
                        });




                  }
                 });


            }
        }
}






