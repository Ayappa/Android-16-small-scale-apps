package com.example.ayappa.imageviewer;

import android.graphics.Bitmap;
import android.os.AsyncTask;

public class AddUrl  {
String url;
StringBuilder string;
MainActivity activity;
String imagename;
//String url;

    public AddUrl(MainActivity activity,String txt,String url) {
        this.activity=activity;
        imagename=txt;
        this.url=url;
    }

    public void connectString(){

 string.append(url);
 string.append("?");
 string.append(imagename);

    }

    public static interface async{
      //  public handlelist(Bitmap bm);
    }
}
