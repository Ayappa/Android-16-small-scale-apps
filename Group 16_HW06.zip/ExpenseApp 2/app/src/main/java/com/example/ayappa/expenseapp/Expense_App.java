package com.example.ayappa.expenseapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.format.Time;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Expense_App.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Expense_App#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Expense_App extends Fragment {
ArrayList<list_details> objects=new ArrayList<list_details>();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("messages");
     int total=0;

     Uri filepath;
    TextView name;
     TextView txt;
     EditText messgae;
     ImageView imageView;
      // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    String Storage_Path = "All_Image_Uploads/";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public Expense_App() {
        // Required empty public constructor
    }




    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Expense_App.
     */
    // TODO: Rename and change types and number of parameters
    public static Expense_App newInstance(String param1, String param2) {
        Expense_App fragment = new Expense_App();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);

        }
        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        objects.clear();
        if (getArguments() != null) {

        }


        return inflater.inflate(R.layout.fragment_expense__app, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction();
    }



    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
         messgae=(EditText)getView().findViewById(R.id.msg);
         imageView=getView().findViewById(R.id.img);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        final RecyclerView recycle;
        final RecyclerView.Adapter[] rAdapter = new RecyclerView.Adapter[1];
        RecyclerView.LayoutManager rmanager;
        recycle = getView().findViewById(R.id.recyle);
        recycle.setHasFixedSize(true);
        rmanager = new LinearLayoutManager(getView().getContext());
        recycle.setLayoutManager(rmanager);
        if (user != null) {
         name=(TextView)getView().findViewById(R.id.name);
        name.setText(user.getDisplayName());
        }
        getActivity().setTitle("Contacts");


        txt= getView().findViewById(R.id.textView);

        objects.clear();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("messages");
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {int i=1;
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    list_details user = child.getValue(list_details.class);

                    String name = user.name.toString();
                    String message = user.message.toString();
                    String date = user.time.toString();
                   // String image=user.image.toString();
                    String image;
                    if(user.image==null){
                        image=null;
                        //image="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGctOjoXR-2V9NjLMumQ3TkwCgDg3vzLZNiTcqH3lbv8BdKDoX";
                    }
                     else{  image=user.image.toString();}
                    list_details obj = new list_details(message,  image, name,date,child.getKey());
                    objects.add(obj);
                   // int rupess=Integer.parseInt(user.amount);
                   // total=total+rupess;
                    if(objects.size()>0){
                        txt.setText("");
                    }else{ txt.setText("No messages to Display");}

                   // compareDate compareDate1=new compareDate();
                   // Collections.sort(objects,new compareDate());
                    Log.d("demo1", "view" + i++);
                    Log.d("demo1", "objec_size" +objects.size());
                    rAdapter[0] = new Adapter(objects);
                    recycle.setAdapter(rAdapter[0]);

                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }

        });




       imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Please Select Image"), 1);
                LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(getContext());
                lbm.registerReceiver(receiver, new IntentFilter("fillter_data12"));
            }
        });

        getView().findViewById(R.id.send).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (messgae.getText().toString().length() == 0) {
                    Toast.makeText(getContext(), "Enter message to send", Toast.LENGTH_LONG).show();
                } else {
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = database.getReference("messages");
                    final String key = myRef.push().getKey();

                    //list_details list_details1=new list_details(name.getText().toString(),f)
                    if (filepath == null) {

                        Time today = new Time(Time.getCurrentTimezone());
                        today.setToNow();
                        list_details list_details1 = new list_details(messgae.getText().toString(), null, name.getText().toString(), today.format("%k:%M:%S"), key);
                        myRef.child(key).setValue(list_details1);
                        messgae.setText("");
                        updateMessage();
                    } else {

                        StorageReference storageReference;
                        storageReference = FirebaseStorage.getInstance().getReference();
                        final StorageReference storageReference2nd = storageReference.child(key);
                        UploadTask uploadTask = storageReference2nd.putFile(filepath);


                        Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                            @Override
                            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                                if (!task.isSuccessful()) {
                                    throw task.getException();
                                }
                                Log.d("demo123q1---return", String.valueOf(storageReference2nd.getDownloadUrl()));

                                // Continue with the task to get the download URL
                                return storageReference2nd.getDownloadUrl();
                            }
                        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task) {
                                if (task.isSuccessful()) {
                                    Uri downloadUri = task.getResult();
                                    Time today = new Time(Time.getCurrentTimezone());
                                    today.setToNow();
                                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                                    DatabaseReference myRef = database.getReference("messages");
                                    list_details list_details1 = new list_details(messgae.getText().toString(), downloadUri.toString(), name.getText().toString(), today.format("%k:%M:%S"), key);
                                    myRef.child(key).setValue(list_details1);
                                    messgae.setText("");
                                    updateMessage();


                                } else {
                                    // Handle failures
                                    // ...
                                }
                            }
                        });

                    }

                }
            }
        });
        getView().findViewById(R.id.logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                getFragmentManager().beginTransaction().replace(R.id.layout, new Login(), "Login").addToBackStack(null).commit();



            }
        });

    }
   public  void updateMessage(){
       objects.clear();
       FirebaseDatabase database = FirebaseDatabase.getInstance();
       DatabaseReference myRef = database.getReference("messages");
       myRef.addListenerForSingleValueEvent(new ValueEventListener() {
           @Override
           public void onDataChange(DataSnapshot dataSnapshot) {int i=1;
               for (DataSnapshot child : dataSnapshot.getChildren()) {
                   list_details user = child.getValue(list_details.class);

                   String name = user.name.toString();
                   String message = user.message.toString();
                   String date = user.time.toString();
                   // String image=user.image.toString();
                   String image;
                   if(user.image==null){
                       image=null;
                      // image="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGctOjoXR-2V9NjLMumQ3TkwCgDg3vzLZNiTcqH3lbv8BdKDoX";
                   }
                   else{  image=user.image.toString();}
                   list_details obj = new list_details(message,  image, name,date,child.getKey());
                   objects.add(obj);
                   // int rupess=Integer.parseInt(user.amount);
                   // total=total+rupess;
                   if(objects.size()>0){
                       txt.setText("");
                   }else{ txt.setText("No messgaes to Display");}

                   // compareDate compareDate1=new compareDate();
                   // Collections.sort(objects,new compareDate());
                   Log.d("demo1", "view" + i++);
                   Log.d("demo1", "objec_size" +objects.size());
                   final RecyclerView recycle;
                   RecyclerView.Adapter rAdapter;
                   RecyclerView.LayoutManager rmanager;
                   recycle = getView().findViewById(R.id.recyle);
                   recycle.setHasFixedSize(true);
                   rmanager = new LinearLayoutManager(getView().getContext());
                   recycle.setLayoutManager(rmanager);
                   rAdapter = new Adapter(objects);
                   recycle.setAdapter(rAdapter);
               }
           }


           @Override
           public void onCancelled(@NonNull DatabaseError databaseError) {

           }

       });

   }

    public BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                filepath = Uri.parse(intent.getStringExtra("url"));
                Log.d("demo","in brodcast"+filepath.toString());
                imageView.setImageURI(filepath);


                // get all your data from intent and do what you want
            }else
                filepath=null;
        }
    };

}
