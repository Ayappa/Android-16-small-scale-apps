/////// Assignment: HOME 3
////// File Name: iTunesMusicSearch
/////  Names: Amith Yarra
/////         Ayappa Krishnappa
/////         Shashank Chandrashekar

package com.example.ayappa.itunesmusicsearch;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    EditText name;
    String searchName="";
    Button search;
    Button reset;
    StringBuilder UrlName=new StringBuilder();
    String url;
    SeekBar seek;
    int seekValue=10;
    TextView seekText;
    ArrayList<Track> detailsObjects=new ArrayList<Track>();
    RecyclerView recycle;
    RecyclerView.Adapter rAdapter;
    RecyclerView.LayoutManager rmanager;
    Switch s;
    int state;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         name=(EditText)findViewById(R.id.editText);
         search=(Button)findViewById(R.id.button);
         seek=(SeekBar)findViewById(R.id.seekBar);
         seekText=(TextView)findViewById(R.id.textView);
         s=(Switch)findViewById(R.id.switch1);
         s.getText();
         recycle=(RecyclerView)findViewById(R.id.recycle);
         recycle.setHasFixedSize(true);
         rmanager=new LinearLayoutManager(this);
         recycle.setLayoutManager(rmanager);


         seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
             @Override
             public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                 seekValue=progress+10;
                 seekText.setText("Limit :" + seekValue);
             }

             @Override
             public void onStartTrackingTouch(SeekBar seekBar) {

             }

             @Override
             public void onStopTrackingTouch(SeekBar seekBar) {

             }
         });


        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detailsObjects.clear();
                Collections.sort(detailsObjects, new comparePrise());
                rAdapter=new ItunesAdapter(detailsObjects);
                recycle.setAdapter(rAdapter);
                UrlName.setLength(0);
                int i=0;
                searchName=name.getText().toString();
                if(searchName.length()==0){Toast.makeText(MainActivity.this,"Enter to Search",Toast.LENGTH_LONG).show();
                return;
                }
                //search.setEnabled(false);
               // seek.setEnabled(false);
                String[] nameList=searchName.split(" ");
                Log.d("demo",searchName);
                Log.d("demo", String.valueOf(nameList.length));
                UrlName.append("https://itunes.apple.com/search?term=");
                UrlName.append(nameList[0]);
                if(nameList.length>1){
                    UrlName.append("+");
                    UrlName.append(nameList[i++]);
                }
                UrlName.append("&limit=");
                UrlName.append(seekValue);
                url= String.valueOf(UrlName);
                new Itunes().execute(url);
                for(int ii=0;ii<=10000;ii++){}

            }
        });
         s.setChecked(true);
         s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
             @Override
             public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                 if (isChecked) {
                     state = 1;
                     Log.d("demo3", "true");
                     if (detailsObjects.size() != 0) {
                         Collections.sort(detailsObjects, new compareDate());
                         rAdapter=new ItunesAdapter(detailsObjects);
                         recycle.setAdapter(rAdapter);
                     }
                 } else{ state = 0;
                 Log.d("demo3", "false");
                     if (detailsObjects.size() != 0) {
                         Collections.sort(detailsObjects, new comparePrise());
                         rAdapter=new ItunesAdapter(detailsObjects);
                         recycle.setAdapter(rAdapter);
                     }
             }
             }
         });
        reset=findViewById(R.id.button2);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=getIntent();
                finish();
                startActivity(i);
            }
        });

    }




    public class Itunes extends AsyncTask<String, Void, ArrayList<Track>> {
        ArrayList<Track> objects=new ArrayList<Track>();
        ArrayList<String> artist=new ArrayList<String>();
        ProgressDialog progress = new ProgressDialog(MainActivity.this);

        public boolean isNetworkAvailable() {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                return true;
            } else Toast.makeText(MainActivity.this,"No Active internet Connection",Toast.LENGTH_LONG).show();return false;
        }

        @Override
        protected void onPreExecute() {
            progress.setMessage(" Loading ");
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.show();
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<Track> aVoid) {
            detailsObjects=objects;
            if(state==1) {
                Collections.sort(detailsObjects, new compareDate());
            }else
                Collections.sort(detailsObjects, new comparePrise());
            for(int ii=0;ii<=100000;ii++){}
            Log.d("demo33", String.valueOf(detailsObjects.size()));
            rAdapter=new ItunesAdapter(detailsObjects);
            recycle.setAdapter(rAdapter);
            progress.dismiss();
            super.onPostExecute(aVoid);
        }


        @Override
        protected ArrayList<Track> doInBackground(String... strings) {
            if (isNetworkAvailable()) {
                try {
                    URL url = new URL(strings[0]);
                    Log.d("urlss", String.valueOf(url));
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.setRequestMethod("GET");
                    connection.connect();
                    String tags = IOUtils.toString(connection.getInputStream(), "UTF-8");
                    connection.disconnect();
                     String Track;
                     String Artist;
                     String Price;
                     String Date1;
                     String Genere;
                     String Album_price;
                     String Album;
                     String image;
                    JSONObject urlName = new JSONObject(tags);
                    int length= Integer.parseInt(urlName.getString("resultCount"));
                    JSONArray result = urlName.getJSONArray("results");
                    for(int i=0;i<length;i++){
                        JSONObject track =result.getJSONObject(i);
                       Track=track.getString("trackName");
                        Artist=track.getString("artistName");
                        Price=track.getString("trackPrice");
                        Date1=track.getString("releaseDate");
                        Log.d("demo",Date1);
                        SimpleDateFormat spf=new SimpleDateFormat("yyyy-mm-dd");
                        Date newDate=spf.parse(Date1);
                        spf= new SimpleDateFormat("dd MMM yyyy");
                        Date1 = spf.format(newDate);
                        Genere=track.getString("primaryGenreName");
                        Album_price=track.getString("collectionPrice");
                        Album=track.getString("collectionName");
                        image=track.getString("artworkUrl30");
                       Track obj=new Track(Track,Artist,Price,Date1,Genere,Album_price,Album,image);
                        objects.add(obj);

                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }

            return objects;

        }
    }


    public class compareDate implements Comparator<Track> {



        @Override
        public int compare(Track o1, Track o2) {
            int ret = o1.Date.compareTo(o2.Date);

            return ret;
        }
    }
    public class comparePrise implements Comparator<Track> {



        @Override
        public int compare(Track o1, Track o2) {
            int ret = o1.Price.compareTo(o2.Price);

            return ret;
        }
    }

}
