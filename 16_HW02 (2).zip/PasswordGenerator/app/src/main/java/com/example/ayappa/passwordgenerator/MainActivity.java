package com.example.ayappa.passwordgenerator;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    Handler handler;
    int Tcount=1;
    int Tlength=7;
   int Acount=1;
   int Alength=7;int i=0;int aa=0;int tt=0;
    ArrayList<String> Aarray = new ArrayList<String>();
     ArrayList<String> Tarray = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       SeekBar sk1=(SeekBar) findViewById(R.id.seekBar);
        final TextView tx3=(TextView)findViewById(R.id.textView3);
        tx3.setText( String.valueOf(sk1.getProgress()+1));

        sk1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
           @Override
           public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
             tx3.setText( String.valueOf(progress+1));
               Tcount=progress+1;
           }

           @Override
           public void onStartTrackingTouch(SeekBar seekBar) {

           }

           @Override
           public void onStopTrackingTouch(SeekBar seekBar) {

           }
       });


       final SeekBar sk2=(SeekBar)findViewById(R.id.seekBar2);
       final TextView tx6=(TextView)findViewById(R.id.textView6);
        tx6.setText(String.valueOf(sk2.getProgress()+7));

        sk2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tx6.setText( String.valueOf(progress+7));
                Tlength=progress+7;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        final SeekBar sk3=(SeekBar)findViewById(R.id.seekBar3);
        final TextView tx8=(TextView)findViewById(R.id.textView8);
        tx8.setText(String.valueOf(sk3.getProgress()+1));

        sk3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tx8.setText( String.valueOf(progress+1));
                Acount=progress+1;

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        final SeekBar sk4=(SeekBar)findViewById(R.id.seekBar4);
        final TextView tx10=(TextView)findViewById(R.id.textView10);
        tx10.setText(String.valueOf(sk4.getProgress()+7));

        sk4.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tx10.setText( String.valueOf(progress+7));
                Alength=progress+7;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               for(i=0;i<Tcount;i++) {
                   handler = new Handler(new Handler.Callback() {
                       @Override
                       public boolean handleMessage(Message msg) {
                           String Tpass = (String) msg.getData().get("pass");
                           Tarray.add(Tpass);
                           tt++;
                           return true;
                       }
                   });
                   ExecutorService task = Executors.newFixedThreadPool(5);
                   task.execute(new ThredPassword(Tlength));
               }
                    new Apassword().execute(Alength);

            }

        });

    }


public class ThredPassword implements Runnable {
        int length;
 ThredPassword(int length){
     this.length=length;
    }


    @Override
    public void run() {
        String Tpassword = Util.getPassword(length);
        Message msg = Message.obtain();
        Bundle b = new Bundle();
        b.putString("pass", Tpassword);
        msg.setData(b);
       handler.sendMessageAtFrontOfQueue(msg);
    }
}


    class Apassword extends AsyncTask<Integer, Integer, ArrayList<String>> {

        ProgressDialog dialog = new ProgressDialog(MainActivity.this);

        @Override
        protected void onPreExecute() {
            dialog.setMessage("Generating password");
            dialog.setMax(Acount+Tcount);
            dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            dialog.setCancelable(false);
            dialog.show();
        }

        @Override
        protected ArrayList<String> doInBackground(Integer... integers) {
            for(int j=0;j<Acount;j++) {
                String Tpassword = Util.getPassword(integers[0]);
                Aarray.add(Tpassword);
                aa++;
                publishProgress(aa+tt);
            }
            for(int m=100;m<10000;m++){publishProgress(aa+tt);}
            return Aarray;
        }
        @Override
        protected void onProgressUpdate(Integer... values) {
            dialog.setProgress(values[0]);

        }
        @Override
        protected void onPostExecute(ArrayList<String> result) {
            dialog.dismiss();
            Intent intent =new Intent(MainActivity.this,Generated_Password.class);
            intent.putStringArrayListExtra("thread",Tarray);
            intent.putStringArrayListExtra("async",Aarray);
            startActivity(intent);
        }

    }


}
