package com.example.ayappa.passwordgenerator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Generated_Password extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generated__password);
        Intent i=getIntent();
        ArrayList<String> Aarray = new ArrayList<String>();
        ArrayList<String> Tarray = new ArrayList<String>();
        Aarray=i.getStringArrayListExtra("thread");
        Tarray=i.getStringArrayListExtra("async");
        ArrayAdapter<String>arrayAdapteT = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,Tarray);
        ListView Tlist=(ListView)findViewById(R.id.list1);
        Tlist.setAdapter(arrayAdapteT);

        ArrayAdapter<String>arrayAdapterA = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,Aarray);
        ListView Alist=(ListView)findViewById(R.id.list2);
        Alist.setAdapter(arrayAdapterA);
    }
}
