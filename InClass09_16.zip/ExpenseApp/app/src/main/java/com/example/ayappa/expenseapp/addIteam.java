package com.example.ayappa.expenseapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.Date;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link addIteam.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link addIteam#newInstance} factory method to
 * create an instance of this fragment.
 */
public class addIteam extends Fragment {
 Date date1;
    TextView textView;
    ImageView imageView;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("contacts");
    String uid;
    Uri  filePath;
    String url;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public addIteam() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment addIteam.
     */
    // TODO: Rename and change types and number of parameters
    public static addIteam newInstance(String param1, String param2) {
        addIteam fragment = new addIteam();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_add_iteam, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//        if (context instanceof OnFragmentInteractionListener) {
//            mListener = (OnFragmentInteractionListener) context;
//        } else {
//            throw new RuntimeException(context.toString()
//                    + " must implement OnFragmentInteractionListener");
//        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }




    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction2(String name,String cat,String amount);
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getActivity().setTitle("Add Expense");
        final EditText name1=getView().findViewById(R.id.name);
        final EditText phone1=getView().findViewById(R.id.phone);
        final EditText email1=getView().findViewById(R.id.email);

        if (getArguments() != null) {
            uid=getArguments().getString("uid");
        }

        imageView=getView().findViewById(R.id.Rimage);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, 0);
                LocalBroadcastManager lbm = LocalBroadcastManager.getInstance(getContext());
                lbm.registerReceiver(receiver1, new IntentFilter("fillter_data12"));
            }
        });

        getView().findViewById(R.id.submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(name1.getText().toString().length()==0 || phone1.getText().toString().length()==0 || email1.getText().toString().length()==0){
                    Toast.makeText(getContext(), "Please enter contact details!", Toast.LENGTH_SHORT).show();
                }
                else {
                    //FirebaseDatabase database = FirebaseDatabase.getInstance();
                    // DatabaseReference myRef = database.getReference("contacts");
                    StorageReference storageReference;
                    DatabaseReference databaseReference;
                    list_details list_details1 = new list_details(name1.getText().toString(), phone1.getText().toString(), email1.getText().toString(), url, uid);
                    ;
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = database.getReference(uid);
                    final String key = myRef.push().getKey();
                    myRef.child(key).setValue(list_details1);
                    getFragmentManager().popBackStack();
                }
            }
        });

    }

    public BroadcastReceiver receiver1 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
               // Log.d("demo123",url);
                if(intent.getStringExtra("url") == null){
                    url = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQD7xhLH2pK72ZdJ5eslngdvqvAdgdzM3Q0mR4kq5G-KY0ZhunP7w";
                }
                else{
                    url= intent.getStringExtra("url");
                    Picasso.with(getContext()).load(url).into(imageView);
                }
            }

        }
    };


}









