package com.example.ayappa.expenseapp;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Expense_App.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Expense_App#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Expense_App extends Fragment {
ArrayList<list_details> objects=new ArrayList<list_details>();
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference().child("expenseList");
     int total=0;
      // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    String Storage_Path = "All_Image_Uploads/";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public Expense_App() {
        // Required empty public constructor
    }




    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Expense_App.
     */
    // TODO: Rename and change types and number of parameters
    public static Expense_App newInstance(String param1, String param2) {
        Expense_App fragment = new Expense_App();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);

        }
        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        objects.clear();
        if (getArguments() != null) {

        }


        return inflater.inflate(R.layout.fragment_expense__app, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.game_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
        }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_game: {
                Toast.makeText(getContext(), "menu1", Toast.LENGTH_SHORT).show();
                Toast.makeText(getContext(), "menu2", Toast.LENGTH_SHORT).show();

                Collections.sort(objects,new compareDate1());
                final RecyclerView recycle;
                RecyclerView.Adapter rAdapter;
                RecyclerView.LayoutManager rmanager;
                recycle = getView().findViewById(R.id.recyle);
                recycle.setHasFixedSize(true);
                rmanager = new LinearLayoutManager(getView().getContext());
                recycle.setLayoutManager(rmanager);
                rAdapter = new Adapter(objects);
                recycle.setAdapter(rAdapter);

            }
                return true;
            case R.id.help: {
                Toast.makeText(getContext(), "menu2", Toast.LENGTH_SHORT).show();

                Collections.sort(objects,new compareDate());
                final RecyclerView recycle;
                RecyclerView.Adapter rAdapter;
                RecyclerView.LayoutManager rmanager;
                recycle = getView().findViewById(R.id.recyle);
                recycle.setHasFixedSize(true);
                rmanager = new LinearLayoutManager(getView().getContext());
                recycle.setLayoutManager(rmanager);
                rAdapter = new Adapter(objects);
                recycle.setAdapter(rAdapter);
            }
                return true;
            case R.id.help1: {

                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("expenseList");

                Log.d("demodemo", String.valueOf(objects.size()));
                 int size=objects.size();
                 for(int m=0;m<size;m++){
                     StorageReference storageReference;
                     DatabaseReference databaseReference;
                     storageReference = FirebaseStorage.getInstance().getReference();
                     final StorageReference storageReference2nd = storageReference.child(objects.get(m).key+".jpg");
                     storageReference2nd.delete();
                     Log.d("demodemo","in menu");
                     Log.d("demodemo",objects.get(m).key+".jpg");

                 }

                DatabaseReference root = FirebaseDatabase.getInstance().getReference();
                root.setValue(null);
                getActivity().recreate();
            }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        getActivity().setTitle("Expense App");
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("expenseList");
        final TextView textView=getView().findViewById(R.id.total12);

        final TextView txt= getView().findViewById(R.id.textView);

objects.clear();
         total=0;

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {int i=1;
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    list_details user = child.getValue(list_details.class);
                    String name = user.name.toString();
                    //String cat = user.cat.toString();
                    String amount = user.amount.toString();
                    String date=user.date.toString();
                    String image;
                    if(user.image==null){
                        image="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGctOjoXR-2V9NjLMumQ3TkwCgDg3vzLZNiTcqH3lbv8BdKDoX";
                    }
                     else{  image=user.image.toString();}
                    list_details obj = new list_details(name,  amount, date,image,child.getKey());
                    objects.add(obj);
                    int rupess=Integer.parseInt(user.amount);
                    total=total+rupess;
                    textView.setText(String.valueOf(total+"$"));
                    if(objects.size()>0){
                        txt.setText("");
                    }else{ txt.setText("There are no expenses to show, please add your expenses from the menu");}
                    if (getArguments() != null) {

                    }
                   // compareDate compareDate1=new compareDate();
                    Collections.sort(objects,new compareDate());
                    Log.d("demo1", "view" + i++);
                    Log.d("demo1", "objec_size" +objects.size());
                    final RecyclerView recycle;
                    RecyclerView.Adapter rAdapter;
                    RecyclerView.LayoutManager rmanager;
                    recycle = getView().findViewById(R.id.recyle);
                    recycle.setHasFixedSize(true);
                    rmanager = new LinearLayoutManager(getView().getContext());
                    recycle.setLayoutManager(rmanager);
                    rAdapter = new Adapter(objects);
                    recycle.setAdapter(rAdapter);
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }

        });

        getView().findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.layout,new addIteam(),"secong").addToBackStack(null).commit();
                    //mListener.onFragmentInteraction();
                }
            });


    }


    public class compareDate implements Comparator<list_details> {
        @Override
        public int compare(list_details o1, list_details o2) {
            int ret = o1.date.compareTo(o2.date);
            return ret;

        }

    }

    public class compareDate1 implements Comparator<list_details> {
        @Override
        public int compare(list_details o1, list_details o2) {
            int ret = o1.amount.compareTo(o2.amount);
            return ret;

        }

    }

}
