package com.example.ayappa.recipypuppy;

public class DisplayBean {
    String title;
    String imageUrl;
    String ingredients;
    String httpUrl;

    public DisplayBean(String title, String imageUrl, String ingredients, String httpUrl) {
        this.title = title;
        this.imageUrl = imageUrl;
        this.ingredients = ingredients;
        this.httpUrl = httpUrl;
    }
}
