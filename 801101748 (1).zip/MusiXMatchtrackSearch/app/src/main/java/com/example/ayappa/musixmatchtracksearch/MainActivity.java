package com.example.ayappa.musixmatchtracksearch;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
  SeekBar seek;
  TextView seekText;
  int seekValue=5;
  RadioGroup rg;
  Button search;
  EditText name;
    ArrayList<Track> detailsObjects=new ArrayList<Track>();
    RecyclerView recycle;
    RecyclerView.Adapter rAdapter;
    RecyclerView.LayoutManager rmanager;
    StringBuilder UrlName=new StringBuilder();
    ProgressBar progress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seek=findViewById(R.id.seekBar);
        seekText=findViewById(R.id.textView);
        rg=findViewById(R.id.radioGroup);
        name=findViewById(R.id.editText);
        final ArrayList<Track> detailsObjects=new ArrayList<Track>();
        recycle=(RecyclerView)findViewById(R.id.recyclerView);
        recycle.setHasFixedSize(true);
        rmanager=new LinearLayoutManager(this);
        recycle.setLayoutManager(rmanager);
        progress=findViewById(R.id.progressBar);
        progress.setVisibility(View.INVISIBLE);


        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                seekValue=progress+5;
                Log.d("demo", String.valueOf(progress));
                seekText.setText("Limit:"+ progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        search=findViewById(R.id.button);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(name.length()==0){ Toast.makeText(MainActivity.this,"Enter name",Toast.LENGTH_LONG).show();}
                else {
                    UrlName.setLength(0);
                    String sort;
                    int radioButtonID = rg.getCheckedRadioButtonId();
                    RadioButton radioButton = (RadioButton) rg.findViewById(radioButtonID);
                    //  String selectedtext = (String) radioButton.getText();
                    String selectedtext = (String) radioButton.getText();
                    selectedtext = selectedtext.toLowerCase();
                    String[] names = selectedtext.split(" ");
//                    if (selectedtext == "") {
//                        sort = "s_track_rating=desc";
//                    } else {
//                        sort = "s_artist_rating=desc";
//                    }

                    Log.d("demo", selectedtext);

                    StringBuilder UrlName = new StringBuilder();
                    UrlName.append("http://api.musixmatch.com/ws/1.1/track.search?q_artist=");
                    UrlName.append(name.getText().toString());
                    UrlName.append("&page_size=");
                    UrlName.append(seekValue);
                    UrlName.append("&"+"s" + "_" + names[0] + "_" + names[1] + "=desc");
                    UrlName.append("&apikey=2ed45910119523aaa0bb7efc5e390e64");
                    Log.d("demo", String.valueOf(UrlName));

                    new musicSearch().execute(String.valueOf(UrlName));

                }// http://api.musixmatch.com/ws/1.1/track.search?q_artist=justin bieber&page_size=3&page=1&s_track_rating=desc

            }
        });






        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(name.length()==0){ Toast.makeText(MainActivity.this,"Enter name",Toast.LENGTH_LONG).show();}
                else {

                    UrlName.setLength(0);
                    String sort;
                    //  int radioButtonID = rg.getCheckedRadioButtonId();
                    RadioButton radioButton = (RadioButton) rg.findViewById(checkedId);
                    String selectedtext = (String) radioButton.getText();
                    selectedtext = selectedtext.toLowerCase();
                    String[] names = selectedtext.split(" ");
                    Log.d("demo", names[0]);

                    UrlName.append("http://api.musixmatch.com/ws/1.1/track.search?q_artist=");
                    UrlName.append(name.getText().toString());
                    UrlName.append("&page_size=");
                    UrlName.append(seekValue);
                    UrlName.append("&"+"s" + "_" + names[0] + "_" + names[1] + "=desc");
                    UrlName.append("&apikey=2ed45910119523aaa0bb7efc5e390e64");
                    Log.d("demo12344", String.valueOf(UrlName));

                    new musicSearch().execute(String.valueOf(UrlName));

                }
               // http://api.musixmatch.com/ws/1.1/track.search?q_artist=a&page_size=5s_artist_rating=desc&apikey=2ed45910119523aaa0bb7efc5e390e64
                //2019-03-11 21:22:12.320 14418-14418/com.example.ayappa.musixmatchtracksearch D/demo123: Track
            }
        });
    }









    public class musicSearch extends AsyncTask<String, Void, ArrayList<Track>> {
        ArrayList<Track> objects=new ArrayList<Track>();
        ArrayList<String> artist=new ArrayList<String>();
       // ProgressDialog progress = new ProgressDialog(MainActivity.this);

        public boolean isNetworkAvailable() {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                return true;
            } else Toast.makeText(MainActivity.this,"No Active internet Connection",Toast.LENGTH_LONG).show();return false;
        }

        @Override
        protected void onPreExecute() {
           progress.setVisibility(View.VISIBLE);
          // detailsObjects.clear();
          // objects.clear();
        }

        @Override
        protected void onPostExecute(ArrayList<Track> aVoid) {
            detailsObjects=aVoid;

            for(int ii=0;ii<=100000;ii++){}
            Log.d("demo33", String.valueOf(detailsObjects.size()));
            rAdapter=new ItunesAdapter(aVoid);
            recycle.setAdapter(rAdapter);
           progress.setVisibility(View.INVISIBLE);
           super.onPostExecute(aVoid);
        }


        @Override
        protected ArrayList<Track> doInBackground(String... strings) {
            if (isNetworkAvailable()) {
                try {
                    Log.d("demo1234", strings[0]);

                    URL url = new URL(strings[0]);
                    Log.d("urlss", String.valueOf(url));
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.setRequestMethod("GET");
                    connection.connect();
                    String tags = IOUtils.toString(connection.getInputStream(), "UTF-8");
                    Log.d("demo", tags);

                    connection.disconnect();
                    String track1;
                    String album;
                    String artist;
                    String time1;
                    String url1;
                    JSONObject urlName1 = new JSONObject(tags);

                    //int length= Integer.parseInt(urlName.getString("resultCount"));
                    JSONObject result = urlName1.getJSONObject("message");
                    JSONObject result1 = result.getJSONObject("body");
                    JSONArray result2 = result1.getJSONArray("track_list");
                                     for(int i=0;i<result2.length();i++) {

                                         JSONObject result3 = result2.getJSONObject(i);

                                         Log.d("demo", String.valueOf(result3.length()));
                                         JSONObject trackjson = result3.getJSONObject("track");

                                         track1=trackjson.getString("track_name");
                        album=trackjson.getString("album_name");
                        artist=trackjson.getString("artist_name");
                        time1=trackjson.getString("updated_time");
                        url1=trackjson.getString("track_share_url");
                        Log.d("demo",album);
                      SimpleDateFormat spf=new SimpleDateFormat("yyyy-mm-dd");
                       Date newDate=spf.parse(time1);
                       spf= new SimpleDateFormat("dd MMM yyyy");
                                         time1 = spf.format(newDate);

                        Track obj=new Track(track1,album,artist,time1,url1);
                        objects.add(obj);


                                     }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }

            return objects;

        }
    }


}
