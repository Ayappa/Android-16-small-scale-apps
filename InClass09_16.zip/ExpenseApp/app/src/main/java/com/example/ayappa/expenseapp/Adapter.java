package com.example.ayappa.expenseapp;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
         Context context;
        ArrayList<list_details> detailsObjects;
        public Adapter(ArrayList<list_details> detailsObjects) {
            this.detailsObjects=detailsObjects;
        }

        public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.show,viewGroup,false);
            ViewHolder viewHolder=new ViewHolder(view);
           context= viewGroup.getContext();
            return viewHolder;
        }

        @Override

        public void onBindViewHolder(@NonNull Adapter.ViewHolder viewHolder, int i) {
            list_details details=detailsObjects.get(i);
            viewHolder.name.setText((CharSequence) details.name);
            viewHolder.phone.setText("$"+(CharSequence) details.phone);
            viewHolder.email.setText((CharSequence) details.email);
           // Context context = null;
            Picasso.with(context).load(String.valueOf(details.image)).into(viewHolder.image);
            viewHolder.details1=details;
            viewHolder.list_detailsArrayList=detailsObjects;
            viewHolder.position=i;

        }

        @Override

        public int getItemCount() {

            return detailsObjects.size();

        }

        public static class ViewHolder extends RecyclerView.ViewHolder{

            TextView name;

            TextView phone;
            TextView email;
            ImageView image;
            OnFragmentInteractionListener mListerner;
            public interface OnFragmentInteractionListener {
                // TODO: Update argument type and name
                void onFragmentInteraction(int position);
            }


            ArrayList<list_details> list_detailsArrayList=new ArrayList<list_details>();
            list_details details1;
            private int position;

            public ViewHolder(@NonNull final View itemView) {

                super(itemView);
                name=(TextView)itemView.findViewById(R.id.Name);
                phone=(TextView)itemView.findViewById(R.id.Phone);
                email=(TextView)itemView.findViewById(R.id.email);
                image=(ImageView)itemView.findViewById(R.id.imageView);

//                itemView.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        if(list_detailsArrayList.size()==0 || details1==null){Toast.makeText(v.getContext(),"Enter details To view",Toast.LENGTH_LONG).show();}else {
//                            final ArrayList<String> keys = new ArrayList<String>();
//                            FirebaseDatabase database = FirebaseDatabase.getInstance();
//                            final DatabaseReference myRef = database.getReference().child("expenseList");
//                            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
//                                @Override
//                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                                    int ii = 0;
//                                    for (DataSnapshot child : dataSnapshot.getChildren()) {
//                                        list_details user = child.getValue(list_details.class);
//                                        keys.add(child.getKey());
//                                    }
//                                    //Log.d("demo123qw", String.valueOf(keys.size()));
//                                   // Log.d("demo123qw", String.valueOf(position));
//
//                                    String key;
//                                    String name = details1.name;
//                                    //String cat = details1.cat;
//                                    String amount = details1.amount;
//                                    String date=details1.date;
//                                    String image= (String) details1.image;
//                                    //String date = details1.currentTime;
//                                    if (position < 0) {
//                                        key = null;
//                                    } else {
//                                        key = keys.get(position);
//                                    }
//                                   // int catNO = details1.catNO;
//                                 //   key = keys.get(position);
//                                    Bundle bundle = new Bundle();
//                                    bundle.putString("name", name);
//                                   // bundle.putString("cat", cat);
//                                    bundle.putString("amount", amount);
//                                    bundle.putString("date", date);
//                                    bundle.putString("image", image);
//
//                                    // bundle.putString("Date", date);
//
//                                   bundle.putString("key", key);
//                                   // bundle.putInt("catNO", catNO);
//                                    ShowFragment fragment = new ShowFragment();
//                                    fragment.setArguments(bundle);
//                                    Object context = itemView.getContext();
//                                    FragmentManager manager = ((AppCompatActivity) context).getSupportFragmentManager();
//                                    manager.beginTransaction().replace(R.id.layout, fragment, "third").addToBackStack(null).commit();
//                                }
//
//                                @Override
//                                public void onCancelled(@NonNull DatabaseError databaseError) {
//                                }
//                            });
//
//                        } }
//                });

//                 itemView.setOnLongClickListener(new View.OnLongClickListener() {
//                     @Override
//                     public boolean onLongClick(View v) {
//                         list_detailsArrayList.remove(position);
//                         Toast.makeText(itemView.getContext(),"Iteam is Deleted",Toast.LENGTH_LONG).show();
//                         Log.d("adapter12","seze_ON1;="+list_detailsArrayList.size());
//                         Log.d("adapter12","position_ON1;="+position);
//                         Log.d("adapter12","position_ON2;="+itemView.getContext());
//
//                          final ArrayList<String>keys=new ArrayList<String>();
//                         FirebaseDatabase database = FirebaseDatabase.getInstance();
//                         final DatabaseReference myRef = database.getReference().child("expense");
//                         myRef.addListenerForSingleValueEvent(new ValueEventListener() {
//                             @Override
//                             public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                                 int ii=0;
//                                 for (DataSnapshot child : dataSnapshot.getChildren()) {
//                                     list_details user = child.getValue(list_details.class);
//                                        keys.add(child.getKey());
//                                 }  myRef.child(keys.get(position)).removeValue();
//                                 keys.remove(position);
//                                 Object context = itemView.getContext();
//
//                                 FragmentManager manager = ((AppCompatActivity) context).getSupportFragmentManager();
//
//                                 manager.beginTransaction().replace(R.id.layout, new Expense_App(), "first").addToBackStack(null).commit();
//
//                             }
//                                 @Override
//                                 public void onCancelled(@NonNull DatabaseError databaseError) {
//                                 }
//                         });
//                         return false;
//                     }
//
//                 });
            }





        }

    }






