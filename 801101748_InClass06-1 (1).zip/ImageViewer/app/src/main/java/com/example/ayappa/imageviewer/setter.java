package com.example.ayappa.imageviewer;

public class setter {

String headlines;
String imageurl;
    String description;
    String published;


    public setter(String headlines, String imageurl,String description,String published) {
        this.headlines = headlines;
        this.imageurl = imageurl;
        this.description = description;
        this.published = published;

    }
}
