package com.example.ayappa.imageviewer;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.drawable.IconCompat;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import org.apache.commons.io.IOUtils;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Async extends AsyncTask <String,Void,Bitmap> {
int imagenumber;
public int size;
ProgressBar pg;
MainActivity activity;
ImageView im;

    public Async(int i,MainActivity activity) {
        imagenumber=i;
         this.activity=activity;
         im=(ImageView) activity.findViewById(R.id.imageView);

    }
    @Override
    protected void onPostExecute(Bitmap bitmap) {
        activity.findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
        im.setImageBitmap(bitmap);
        im.setVisibility(View.VISIBLE);
        Log.d("tog12", String.valueOf(imagenumber));
        super.onPostExecute(bitmap);
    }

    @Override
    protected void onPreExecute() {
        activity.findViewById(R.id.progressBar).setVisibility(View.VISIBLE);
        im.setVisibility(View.INVISIBLE);
        super.onPreExecute();
    }

    @Override
    protected Bitmap doInBackground(String... strings) {
        try {
           // activity.findViewById(R.id.imageView).setVisibility(View.INVISIBLE);
            String url1="http://dev.theappsdr.com/apis/photos/index.php";
            String string;
            string=(url1+"?keyword="+strings[0]);
            URL url = new URL(string);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.setRequestMethod("GET");
            connection.connect();
            StringBuilder  stringUrl=new StringBuilder();
            String nama12=IOUtils.toString(connection.getInputStream(),"UTF8");
            String[] stringSpilt = nama12.toString().split("http");
              size=stringSpilt.length;
              Log.d("size", String.valueOf(size));
              String getimage;
             if(size==1){
                  getimage="http://www.clker.com/cliparts/q/L/P/Y/t/6/no-image-available-md.png";//Bitmap bm = BitmapFactory.decodeResource(Resources.getSystem(), R.drawable.no);

              }else {
                  getimage = "http" + stringSpilt[imagenumber + 1];
             }
                  URL urlimage = new URL(getimage);
                  connection = (HttpURLConnection) urlimage.openConnection();
                  connection.setDoInput(true);
                  connection.connect();
                  InputStream input1 = connection.getInputStream();
                  Bitmap myBitmap = BitmapFactory.decodeStream(input1);
            return myBitmap;

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}
