package com.example.amith.plan;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
  static String date1;
  String title;
  Double cityLat;
  Double cityLag;
  String cityName;
  String cityPlace;
  ArrayList<PojoPlace>objects=new ArrayList<PojoPlace>();
  ArrayList<String>Dnames=new ArrayList<String>();
    RecyclerView recycle;
    RecyclerView.Adapter rAdapter;
    RecyclerView.LayoutManager rmanager;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("Places");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recycle=(RecyclerView)findViewById(R.id.recycle);




        final TextView TripName=(TextView)findViewById(R.id.TripName);
        final TextView date=(TextView)findViewById(R.id.date);
        final EditText city=(EditText)findViewById(R.id.city);
        final Spinner visit=findViewById(R.id.spinner);
        final String[] arraySpinner = new String[] {
                "airport", "amusement_park", "aquarium", "car_rental", "museum", "city_hall","parking"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        visit.setAdapter(adapter);
        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment newFragment = new DatePickerFragment();
                newFragment.show(getSupportFragmentManager(), "datePicker");
            }
        });

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Places");
       // DatabaseReference myRef1=database.getReference().child(keys);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d("demo123",dataSnapshot.toString());
                for (DataSnapshot postSnapshot: dataSnapshot.getChildren()) {

                    PojoPlace pojoPlace=postSnapshot.getValue(PojoPlace.class);
                    objects.add(pojoPlace);
                    recycle.setHasFixedSize(true);
                    rmanager=new LinearLayoutManager(MainActivity.this);
                    recycle=(RecyclerView)findViewById(R.id.recycle);
                    recycle.setLayoutManager(rmanager);
                    rAdapter=new ListCod(objects);
                    recycle.setAdapter(rAdapter);
                }
               // PojoPlace pojoPlace=dataSnapshot.getValue(PojoPlace.class);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }


        });








        findViewById(R.id.button3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                title=TripName.getText().toString();
                cityName=city.getText().toString();
                cityPlace=arraySpinner[visit.getSelectedItemPosition()];
                if(TripName.getText().length()==0){
                    Toast.makeText(MainActivity.this, "Enter Trip Name", Toast.LENGTH_SHORT).show();
                }else if(city.getText().length()==0){
                    Toast.makeText(MainActivity.this, "Enter a valid city", Toast.LENGTH_SHORT).show();
                }else if(date1==null){
                    Toast.makeText(MainActivity.this, "Select a Valid Date", Toast.LENGTH_SHORT).show();
                }else {
                    new City().execute("https://maps.googleapis.com/maps/api/place/textsearch/json?key=AIzaSyBXe4wdXlDufj-C249qukB52Kfa0MzmxiQ&query=" + cityName);
//Log.d("demo12",arraySpinner[visit.getSelectedItemPosition()]);
                }

            }
        });


    }



    public class places extends AsyncTask<String, Void, ArrayList<PojoPlace>> {

        @Override
        protected void onPostExecute(ArrayList<PojoPlace> pojoPlaces) {
            super.onPostExecute(pojoPlaces);
          //  myRef.setValue(pojoPlaces);

            recycle.setHasFixedSize(true);
            rmanager=new LinearLayoutManager(MainActivity.this);
            recycle=(RecyclerView)findViewById(R.id.recycle);
            recycle.setLayoutManager(rmanager);
            rAdapter=new ListCod(pojoPlaces);
           recycle.setAdapter(rAdapter);
        }
        public boolean isNetworkAvailable() {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                return true;
            } else Toast.makeText(MainActivity.this, "NO Active Network", Toast.LENGTH_SHORT).show();return false;

        }
        @Override
        protected ArrayList<PojoPlace> doInBackground(String... strings) {
            if (isNetworkAvailable()) {
                URL url = null;
                try {
                    Log.d("demo1", "hi");

                    url = new URL("https://maps.googleapis.com/maps/api/place/textsearch/json?key=AIzaSyBXe4wdXlDufj-C249qukB52Kfa0MzmxiQ&query=" + cityName + "&type=" + cityPlace+"&radius=15000");
                    Log.d("urlss", String.valueOf(url));
                    HttpURLConnection connection = null;
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.setRequestMethod("GET");
                    connection.connect();
                    String json = IOUtils.toString(connection.getInputStream(), "UTF-8");
                    connection.disconnect();
                    Log.d("demo1", json);
                    JSONObject result = new JSONObject(json);
                    JSONArray result1 = result.getJSONArray("results");
                    ArrayList<Double> lat = new ArrayList<>();
                    ArrayList<Double> lag = new ArrayList<>();
                    String name = null;
                    for (int i = 0; i < result1.length(); i++) {
                        JSONObject resultPlace = result1.getJSONObject(i);
                        name = resultPlace.getString("name");
                        Log.d("demo12", "name:" + name);
                        JSONObject location = resultPlace.getJSONObject("geometry");
                        JSONObject locationCOd = location.getJSONObject("location");
                        Log.d("demo12", locationCOd.toString());
                        // String lat=locationCOd.getString("lat");
                        // String log=locationCOd.getString("lng");
                        lat.add(Double.valueOf(locationCOd.getString("lat")));
                        lag.add(Double.valueOf(locationCOd.getString("lng")));
                        Dnames.add(name);
                    }

                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = database.getReference("Places");
                    String key = myRef.child("posts").push().getKey();
                    PojoPlace pojoPlace = new PojoPlace(title, cityName, cityPlace, Dnames, lat, lag, date1, cityLat, cityLag, key);
                    myRef.child(key).setValue(pojoPlace);
                    objects.add(pojoPlace);
                    return objects;

                    // Log.d("demo12", String.valueOf(result1));

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;

        }
    }


    public class City extends AsyncTask<String, Void, Void> {
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            new places().execute("https://maps.googleapis.com/maps/api/place/textsearch/json?key=AIzaSyBXe4wdXlDufj-C249qukB52Kfa0MzmxiQ&query="+cityName+"&type="+cityPlace);
        }
        public boolean isNetworkAvailable() {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo != null && activeNetworkInfo.isConnected()) {
                return true;
            } else Toast.makeText(MainActivity.this, "NO Active Network", Toast.LENGTH_SHORT).show();return false;

        }

        @Override
        protected Void doInBackground(String... strings) {
            if (isNetworkAvailable()) {
                URL url = null;
                try {
                    Log.d("demo1", "hi");

                    url = new URL("https://maps.googleapis.com/maps/api/place/textsearch/json?key=AIzaSyBXe4wdXlDufj-C249qukB52Kfa0MzmxiQ&query=" + cityName);
                    Log.d("urlss", String.valueOf(url));
                    HttpURLConnection connection = null;
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setDoInput(true);
                    connection.setRequestMethod("GET");
                    connection.connect();
                    String json = IOUtils.toString(connection.getInputStream(), "UTF-8");
                    connection.disconnect();
                    Log.d("demo1", json);
                    JSONObject result = new JSONObject(json);
                    JSONArray result1 = result.getJSONArray("results");
                    for (int i = 0; i < result1.length(); i++) {
                        JSONObject resultPlace = result1.getJSONObject(i);
                        JSONObject location = resultPlace.getJSONObject("geometry");
                        JSONObject locationCOd = location.getJSONObject("location");
                        Log.d("demo12", locationCOd.toString());
                        cityLat = Double.valueOf(locationCOd.getString("lat"));
                        cityLag = Double.valueOf(locationCOd.getString("lng"));
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
                return null;

        }
    }





    public static class DatePickerFragment extends DialogFragment
            implements DatePickerDialog.OnDateSetListener {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the current date as the default date in the picker
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            // Create a new instance of DatePickerDialog and return it
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            // Do something with the date chosen by the user
           TextView date= getActivity().findViewById(R.id.date);
           date.setText(month+"/"+day+"/"+year);
           date1=month+"/"+day+"/"+year;
        }
    }
}
