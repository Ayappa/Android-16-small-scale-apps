package com.example.ayappa.musixmatchtracksearch;

public class Track {
    String track;
    String album;
    String artist;
    String time;
    String url;


    public Track(String track, String album, String artist, String time, String url) {
        this.track = track;
        this.album = album;
        this.artist = artist;
        this.time = time;
        this.url = url;
    }
}
