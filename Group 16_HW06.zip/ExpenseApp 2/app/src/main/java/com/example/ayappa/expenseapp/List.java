package com.example.ayappa.expenseapp;

class list_details{

    String name;
    String image;
    String message;
    String time;
    String key;
list_details(){}
    public list_details(String message, String image, String name,  String time,String key) {
        this.name = name;
       // this.cat = cat;
        this.message = message;
       this.image = image;
       this.time=time;
       this.key=key;
    }
}
