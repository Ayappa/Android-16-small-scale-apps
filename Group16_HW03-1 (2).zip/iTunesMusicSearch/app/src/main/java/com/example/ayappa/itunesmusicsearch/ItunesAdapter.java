package com.example.ayappa.itunesmusicsearch;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;

class ItunesAdapter extends RecyclerView.Adapter<ItunesAdapter.ViewHolder> {
    ArrayList<Track> detailsObjects;




    public ItunesAdapter(ArrayList<Track> detailsObjects) {
        this.detailsObjects=detailsObjects;

    }

    @NonNull
    @Override
    public ItunesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.display,viewGroup,false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ItunesAdapter.ViewHolder viewHolder, int i) {
        Track track=detailsObjects.get(i);
        viewHolder.TrackName.setText((CharSequence) track.Track);
        viewHolder.ArtistName.setText((CharSequence) track.Artist);
        viewHolder.PriceAmount.setText((CharSequence) track.Price);
        viewHolder.DateOf.setText((CharSequence) track.Date);
        viewHolder.tunesInfo=track;

    }

    @Override
    public int getItemCount() {
        return detailsObjects.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView Track;
        TextView TrackName;
        TextView Artist;
        TextView ArtistName;
        TextView Price;
        TextView PriceAmount;
        TextView Date;
        TextView DateOf;
        Track tunesInfo;
        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            Track=(TextView)itemView.findViewById(R.id.textView6);
            TrackName=(TextView)itemView.findViewById(R.id.textView10);
            Artist=(TextView)itemView.findViewById(R.id.textView8);
            ArtistName=(TextView)itemView.findViewById(R.id.textView11);
            Price=(TextView)itemView.findViewById(R.id.textView7);
            PriceAmount=(TextView)itemView.findViewById(R.id.textView13);
            Date=(TextView)itemView.findViewById(R.id.textView9);
            DateOf=(TextView)itemView.findViewById(R.id.textView12);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(itemView.getContext(),Result.class);
                    Bundle bundel=new Bundle();

                    bundel.putString("Track",tunesInfo.Track);
                    bundel.putString("Album",tunesInfo.Album);
                    bundel.putString("Album_price",tunesInfo.Album_price);
                    bundel.putString("Artist",tunesInfo.Artist);
                    bundel.putString("Date",tunesInfo.Date);
                    bundel.putString("Genere",tunesInfo.Genere);
                    bundel.putString("image",tunesInfo.image);
                    bundel.putString("Price",tunesInfo.Price);
                    intent.putExtra("key",bundel);
                    itemView.getContext().startActivities(new Intent[]{intent});




                }
            });

        }
    }
}
